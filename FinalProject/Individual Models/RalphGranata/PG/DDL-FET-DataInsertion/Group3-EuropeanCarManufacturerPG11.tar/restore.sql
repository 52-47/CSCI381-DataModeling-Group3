--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.15
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Group3-EuropeanCarManufacturerPG11";
--
-- Name: Group3-EuropeanCarManufacturerPG11; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Group3-EuropeanCarManufacturerPG11" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "Group3-EuropeanCarManufacturerPG11" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Group3-EuropeanCarManufacturerPG11'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Audit; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Audit";


ALTER SCHEMA "Audit" OWNER TO postgres;

--
-- Name: CustomViews; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "CustomViews";


ALTER SCHEMA "CustomViews" OWNER TO postgres;

--
-- Name: DbSecurity; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "DbSecurity";


ALTER SCHEMA "DbSecurity" OWNER TO postgres;

--
-- Name: Hashing; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Hashing";


ALTER SCHEMA "Hashing" OWNER TO postgres;

--
-- Name: HumanResources; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "HumanResources";


ALTER SCHEMA "HumanResources" OWNER TO postgres;

--
-- Name: Locale; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Locale";


ALTER SCHEMA "Locale" OWNER TO postgres;

--
-- Name: Output; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Output";


ALTER SCHEMA "Output" OWNER TO postgres;

--
-- Name: Production; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Production";


ALTER SCHEMA "Production" OWNER TO postgres;

--
-- Name: RawData; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "RawData";


ALTER SCHEMA "RawData" OWNER TO postgres;

--
-- Name: Sales; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Sales";


ALTER SCHEMA "Sales" OWNER TO postgres;

--
-- Name: SequenceIdInsert; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "SequenceIdInsert";


ALTER SCHEMA "SequenceIdInsert" OWNER TO postgres;

--
-- Name: Utils; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Utils";


ALTER SCHEMA "Utils" OWNER TO postgres;

--
-- Name: dEuropeanCarManufacturer; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "dEuropeanCarManufacturer";


ALTER SCHEMA "dEuropeanCarManufacturer" OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: sdAddressesString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdAddressesString";


ALTER SCHEMA "sdAddressesString" OWNER TO postgres;

--
-- Name: sdAudit; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdAudit";


ALTER SCHEMA "sdAudit" OWNER TO postgres;

--
-- Name: sdBlob; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdBlob";


ALTER SCHEMA "sdBlob" OWNER TO postgres;

--
-- Name: sdBusinessComponentString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdBusinessComponentString";


ALTER SCHEMA "sdBusinessComponentString" OWNER TO postgres;

--
-- Name: sdCountryStringVariant; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdCountryStringVariant";


ALTER SCHEMA "sdCountryStringVariant" OWNER TO postgres;

--
-- Name: sdDate; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdDate";


ALTER SCHEMA "sdDate" OWNER TO postgres;

--
-- Name: sdDateTime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdDateTime";


ALTER SCHEMA "sdDateTime" OWNER TO postgres;

--
-- Name: sdFlag; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdFlag";


ALTER SCHEMA "sdFlag" OWNER TO postgres;

--
-- Name: sdHashKey; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdHashKey";


ALTER SCHEMA "sdHashKey" OWNER TO postgres;

--
-- Name: sdKey; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdKey";


ALTER SCHEMA "sdKey" OWNER TO postgres;

--
-- Name: sdLongTextString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdLongTextString";


ALTER SCHEMA "sdLongTextString" OWNER TO postgres;

--
-- Name: sdMarketingTextString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdMarketingTextString";


ALTER SCHEMA "sdMarketingTextString" OWNER TO postgres;

--
-- Name: sdNameString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdNameString";


ALTER SCHEMA "sdNameString" OWNER TO postgres;

--
-- Name: sdNumber; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdNumber";


ALTER SCHEMA "sdNumber" OWNER TO postgres;

--
-- Name: sdOrdinalNumber; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdOrdinalNumber";


ALTER SCHEMA "sdOrdinalNumber" OWNER TO postgres;

--
-- Name: sdProjectString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdProjectString";


ALTER SCHEMA "sdProjectString" OWNER TO postgres;

--
-- Name: sdSequenceNumber; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdSequenceNumber";


ALTER SCHEMA "sdSequenceNumber" OWNER TO postgres;

--
-- Name: sdShortTextString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdShortTextString";


ALTER SCHEMA "sdShortTextString" OWNER TO postgres;

--
-- Name: sdString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdString";


ALTER SCHEMA "sdString" OWNER TO postgres;

--
-- Name: sdTimeString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdTimeString";


ALTER SCHEMA "sdTimeString" OWNER TO postgres;

--
-- Name: sdVehicleString; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "sdVehicleString";


ALTER SCHEMA "sdVehicleString" OWNER TO postgres;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: sdBlob; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdBlob" AS bytea;


ALTER DOMAIN "dEuropeanCarManufacturer"."sdBlob" OWNER TO postgres;

--
-- Name: DOMAIN "sdBlob"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdBlob" IS 'contains all blob and binary types';


--
-- Name: sdDatetime; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdDatetime" AS timestamp without time zone;


ALTER DOMAIN "dEuropeanCarManufacturer"."sdDatetime" OWNER TO postgres;

--
-- Name: DOMAIN "sdDatetime"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdDatetime" IS 'contains all date-time types';


--
-- Name: sdFlag; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdFlag" AS integer;


ALTER DOMAIN "dEuropeanCarManufacturer"."sdFlag" OWNER TO postgres;

--
-- Name: DOMAIN "sdFlag"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdFlag" IS 'contains all flag types';


--
-- Name: sdKey; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdKey" AS integer;


ALTER DOMAIN "dEuropeanCarManufacturer"."sdKey" OWNER TO postgres;

--
-- Name: DOMAIN "sdKey"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdKey" IS 'contains all key types';


--
-- Name: sdNumber; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdNumber" AS integer;


ALTER DOMAIN "dEuropeanCarManufacturer"."sdNumber" OWNER TO postgres;

--
-- Name: DOMAIN "sdNumber"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdNumber" IS 'contains all number types';


--
-- Name: sdString; Type: DOMAIN; Schema: dEuropeanCarManufacturer; Owner: postgres
--

CREATE DOMAIN "dEuropeanCarManufacturer"."sdString" AS character varying(20);


ALTER DOMAIN "dEuropeanCarManufacturer"."sdString" OWNER TO postgres;

--
-- Name: DOMAIN "sdString"; Type: COMMENT; Schema: dEuropeanCarManufacturer; Owner: postgres
--

COMMENT ON DOMAIN "dEuropeanCarManufacturer"."sdString" IS 'contains all string types';


--
-- Name: dEuropeanCarManufacturer; Type: DOMAIN; Schema: public; Owner: postgres
--

CREATE DOMAIN public."dEuropeanCarManufacturer" AS character(18);


ALTER DOMAIN public."dEuropeanCarManufacturer" OWNER TO postgres;

--
-- Name: DOMAIN "dEuropeanCarManufacturer"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON DOMAIN public."dEuropeanCarManufacturer" IS 'The top level domain for European Car Manufacturer Data Model';


--
-- Name: AddressString; Type: DOMAIN; Schema: sdAddressesString; Owner: postgres
--

CREATE DOMAIN "sdAddressesString"."AddressString" AS character varying(60);


ALTER DOMAIN "sdAddressesString"."AddressString" OWNER TO postgres;

--
-- Name: DOMAIN "AddressString"; Type: COMMENT; Schema: sdAddressesString; Owner: postgres
--

COMMENT ON DOMAIN "sdAddressesString"."AddressString" IS 'for street addresses';


--
-- Name: CountryString; Type: DOMAIN; Schema: sdAddressesString; Owner: postgres
--

CREATE DOMAIN "sdAddressesString"."CountryString" AS character varying(50);


ALTER DOMAIN "sdAddressesString"."CountryString" OWNER TO postgres;

--
-- Name: DOMAIN "CountryString"; Type: COMMENT; Schema: sdAddressesString; Owner: postgres
--

COMMENT ON DOMAIN "sdAddressesString"."CountryString" IS 'for country names';


--
-- Name: PostalCodeString; Type: DOMAIN; Schema: sdAddressesString; Owner: postgres
--

CREATE DOMAIN "sdAddressesString"."PostalCodeString" AS character varying(9);


ALTER DOMAIN "sdAddressesString"."PostalCodeString" OWNER TO postgres;

--
-- Name: DOMAIN "PostalCodeString"; Type: COMMENT; Schema: sdAddressesString; Owner: postgres
--

COMMENT ON DOMAIN "sdAddressesString"."PostalCodeString" IS 'for postal codes';


--
-- Name: RegionString; Type: DOMAIN; Schema: sdAddressesString; Owner: postgres
--

CREATE DOMAIN "sdAddressesString"."RegionString" AS character varying(20);


ALTER DOMAIN "sdAddressesString"."RegionString" OWNER TO postgres;

--
-- Name: DOMAIN "RegionString"; Type: COMMENT; Schema: sdAddressesString; Owner: postgres
--

COMMENT ON DOMAIN "sdAddressesString"."RegionString" IS 'for region names';


--
-- Name: TownString; Type: DOMAIN; Schema: sdAddressesString; Owner: postgres
--

CREATE DOMAIN "sdAddressesString"."TownString" AS character varying(30);


ALTER DOMAIN "sdAddressesString"."TownString" OWNER TO postgres;

--
-- Name: DOMAIN "TownString"; Type: COMMENT; Schema: sdAddressesString; Owner: postgres
--

COMMENT ON DOMAIN "sdAddressesString"."TownString" IS 'for town names';


--
-- Name: DbAction; Type: DOMAIN; Schema: sdAudit; Owner: postgres
--

CREATE DOMAIN "sdAudit"."DbAction" AS character(1);


ALTER DOMAIN "sdAudit"."DbAction" OWNER TO postgres;

--
-- Name: DOMAIN "DbAction"; Type: COMMENT; Schema: sdAudit; Owner: postgres
--

COMMENT ON DOMAIN "sdAudit"."DbAction" IS 'for database actions';


--
-- Name: sdHashKey; Type: DOMAIN; Schema: sdBlob; Owner: postgres
--

CREATE DOMAIN "sdBlob"."sdHashKey" AS bytea;


ALTER DOMAIN "sdBlob"."sdHashKey" OWNER TO postgres;

--
-- Name: DOMAIN "sdHashKey"; Type: COMMENT; Schema: sdBlob; Owner: postgres
--

COMMENT ON DOMAIN "sdBlob"."sdHashKey" IS 'for row level hash keys';


--
-- Name: DepartmentString; Type: DOMAIN; Schema: sdBusinessComponentString; Owner: postgres
--

CREATE DOMAIN "sdBusinessComponentString"."DepartmentString" AS character varying(15);


ALTER DOMAIN "sdBusinessComponentString"."DepartmentString" OWNER TO postgres;

--
-- Name: DOMAIN "DepartmentString"; Type: COMMENT; Schema: sdBusinessComponentString; Owner: postgres
--

COMMENT ON DOMAIN "sdBusinessComponentString"."DepartmentString" IS 'for department name';


--
-- Name: CountryISO2; Type: DOMAIN; Schema: sdCountryStringVariant; Owner: postgres
--

CREATE DOMAIN "sdCountryStringVariant"."CountryISO2" AS character varying(2);


ALTER DOMAIN "sdCountryStringVariant"."CountryISO2" OWNER TO postgres;

--
-- Name: DOMAIN "CountryISO2"; Type: COMMENT; Schema: sdCountryStringVariant; Owner: postgres
--

COMMENT ON DOMAIN "sdCountryStringVariant"."CountryISO2" IS 'for Country ISO 2 characters';


--
-- Name: CountryISO3; Type: DOMAIN; Schema: sdCountryStringVariant; Owner: postgres
--

CREATE DOMAIN "sdCountryStringVariant"."CountryISO3" AS character(3);


ALTER DOMAIN "sdCountryStringVariant"."CountryISO3" OWNER TO postgres;

--
-- Name: DOMAIN "CountryISO3"; Type: COMMENT; Schema: sdCountryStringVariant; Owner: postgres
--

COMMENT ON DOMAIN "sdCountryStringVariant"."CountryISO3" IS 'for country ISO 3 characters
';


--
-- Name: DateYYYYMMDD; Type: DOMAIN; Schema: sdDate; Owner: postgres
--

CREATE DOMAIN "sdDate"."DateYYYYMMDD" AS date;


ALTER DOMAIN "sdDate"."DateYYYYMMDD" OWNER TO postgres;

--
-- Name: DOMAIN "DateYYYYMMDD"; Type: COMMENT; Schema: sdDate; Owner: postgres
--

COMMENT ON DOMAIN "sdDate"."DateYYYYMMDD" IS 'date string YYYYMMDD';


--
-- Name: DateTimestamp; Type: DOMAIN; Schema: sdDateTime; Owner: postgres
--

CREATE DOMAIN "sdDateTime"."DateTimestamp" AS timestamp without time zone NOT NULL;


ALTER DOMAIN "sdDateTime"."DateTimestamp" OWNER TO postgres;

--
-- Name: sdDate; Type: DOMAIN; Schema: sdDateTime; Owner: postgres
--

CREATE DOMAIN "sdDateTime"."sdDate" AS date;


ALTER DOMAIN "sdDateTime"."sdDate" OWNER TO postgres;

--
-- Name: DOMAIN "sdDate"; Type: COMMENT; Schema: sdDateTime; Owner: postgres
--

COMMENT ON DOMAIN "sdDateTime"."sdDate" IS 'contains all date types';


--
-- Name: FlagBit; Type: DOMAIN; Schema: sdFlag; Owner: postgres
--

CREATE DOMAIN "sdFlag"."FlagBit" AS integer;


ALTER DOMAIN "sdFlag"."FlagBit" OWNER TO postgres;

--
-- Name: DOMAIN "FlagBit"; Type: COMMENT; Schema: sdFlag; Owner: postgres
--

COMMENT ON DOMAIN "sdFlag"."FlagBit" IS 'integer flag bit';


--
-- Name: FlagYesNoString; Type: DOMAIN; Schema: sdFlag; Owner: postgres
--

CREATE DOMAIN "sdFlag"."FlagYesNoString" AS character(1) NOT NULL;


ALTER DOMAIN "sdFlag"."FlagYesNoString" OWNER TO postgres;

--
-- Name: DOMAIN "FlagYesNoString"; Type: COMMENT; Schema: sdFlag; Owner: postgres
--

COMMENT ON DOMAIN "sdFlag"."FlagYesNoString" IS 'for a flag to indicating Yes or No';


--
-- Name: RowLevelHashKey; Type: DOMAIN; Schema: sdHashKey; Owner: postgres
--

CREATE DOMAIN "sdHashKey"."RowLevelHashKey" AS bytea;


ALTER DOMAIN "sdHashKey"."RowLevelHashKey" OWNER TO postgres;

--
-- Name: DOMAIN "RowLevelHashKey"; Type: COMMENT; Schema: sdHashKey; Owner: postgres
--

COMMENT ON DOMAIN "sdHashKey"."RowLevelHashKey" IS 'for all Row Level Hash Keys and Prior Row Level Hash Keys';


--
-- Name: SurrogateKeyInteger; Type: DOMAIN; Schema: sdKey; Owner: postgres
--

CREATE DOMAIN "sdKey"."SurrogateKeyInteger" AS integer NOT NULL;


ALTER DOMAIN "sdKey"."SurrogateKeyInteger" OWNER TO postgres;

--
-- Name: DOMAIN "SurrogateKeyInteger"; Type: COMMENT; Schema: sdKey; Owner: postgres
--

COMMENT ON DOMAIN "sdKey"."SurrogateKeyInteger" IS 'for all integer primary keys';


--
-- Name: CustomerComments; Type: DOMAIN; Schema: sdLongTextString; Owner: postgres
--

CREATE DOMAIN "sdLongTextString"."CustomerComments" AS character varying(200);


ALTER DOMAIN "sdLongTextString"."CustomerComments" OWNER TO postgres;

--
-- Name: DOMAIN "CustomerComments"; Type: COMMENT; Schema: sdLongTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdLongTextString"."CustomerComments" IS 'for customer comments';


--
-- Name: Note; Type: DOMAIN; Schema: sdLongTextString; Owner: postgres
--

CREATE DOMAIN "sdLongTextString"."Note" AS character varying(100);


ALTER DOMAIN "sdLongTextString"."Note" OWNER TO postgres;

--
-- Name: DOMAIN "Note"; Type: COMMENT; Schema: sdLongTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdLongTextString"."Note" IS 'for notes';


--
-- Name: CustomerSpendCapacity; Type: DOMAIN; Schema: sdMarketingTextString; Owner: postgres
--

CREATE DOMAIN "sdMarketingTextString"."CustomerSpendCapacity" AS character varying(15);


ALTER DOMAIN "sdMarketingTextString"."CustomerSpendCapacity" OWNER TO postgres;

--
-- Name: DOMAIN "CustomerSpendCapacity"; Type: COMMENT; Schema: sdMarketingTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdMarketingTextString"."CustomerSpendCapacity" IS 'for the spending capacity of a customer';


--
-- Name: VehicleSalesThresholdCategory; Type: DOMAIN; Schema: sdMarketingTextString; Owner: postgres
--

CREATE DOMAIN "sdMarketingTextString"."VehicleSalesThresholdCategory" AS character varying(20);


ALTER DOMAIN "sdMarketingTextString"."VehicleSalesThresholdCategory" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleSalesThresholdCategory"; Type: COMMENT; Schema: sdMarketingTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdMarketingTextString"."VehicleSalesThresholdCategory" IS 'for describing the vehicle threshold category';


--
-- Name: CustomerName; Type: DOMAIN; Schema: sdNameString; Owner: postgres
--

CREATE DOMAIN "sdNameString"."CustomerName" AS character varying(65);


ALTER DOMAIN "sdNameString"."CustomerName" OWNER TO postgres;

--
-- Name: DOMAIN "CustomerName"; Type: COMMENT; Schema: sdNameString; Owner: postgres
--

COMMENT ON DOMAIN "sdNameString"."CustomerName" IS 'for customer or business name';


--
-- Name: FirstNameString; Type: DOMAIN; Schema: sdNameString; Owner: postgres
--

CREATE DOMAIN "sdNameString"."FirstNameString" AS character varying(25) NOT NULL;


ALTER DOMAIN "sdNameString"."FirstNameString" OWNER TO postgres;

--
-- Name: DOMAIN "FirstNameString"; Type: COMMENT; Schema: sdNameString; Owner: postgres
--

COMMENT ON DOMAIN "sdNameString"."FirstNameString" IS 'for first names';


--
-- Name: FullNameString; Type: DOMAIN; Schema: sdNameString; Owner: postgres
--

CREATE DOMAIN "sdNameString"."FullNameString" AS character varying(60) NOT NULL;


ALTER DOMAIN "sdNameString"."FullNameString" OWNER TO postgres;

--
-- Name: DOMAIN "FullNameString"; Type: COMMENT; Schema: sdNameString; Owner: postgres
--

COMMENT ON DOMAIN "sdNameString"."FullNameString" IS 'for full names';


--
-- Name: LastNameString; Type: DOMAIN; Schema: sdNameString; Owner: postgres
--

CREATE DOMAIN "sdNameString"."LastNameString" AS character varying(35) NOT NULL;


ALTER DOMAIN "sdNameString"."LastNameString" OWNER TO postgres;

--
-- Name: DOMAIN "LastNameString"; Type: COMMENT; Schema: sdNameString; Owner: postgres
--

COMMENT ON DOMAIN "sdNameString"."LastNameString" IS 'for last names';


--
-- Name: Currency; Type: DOMAIN; Schema: sdNumber; Owner: postgres
--

CREATE DOMAIN "sdNumber"."Currency" AS numeric(18,2);


ALTER DOMAIN "sdNumber"."Currency" OWNER TO postgres;

--
-- Name: DOMAIN "Currency"; Type: COMMENT; Schema: sdNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdNumber"."Currency" IS 'for currency amounts';


--
-- Name: sdOrdinalNumber; Type: DOMAIN; Schema: sdNumber; Owner: postgres
--

CREATE DOMAIN "sdNumber"."sdOrdinalNumber" AS integer NOT NULL;


ALTER DOMAIN "sdNumber"."sdOrdinalNumber" OWNER TO postgres;

--
-- Name: DOMAIN "sdOrdinalNumber"; Type: COMMENT; Schema: sdNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdNumber"."sdOrdinalNumber" IS 'contains all ordinal numbers';


--
-- Name: sdSequenceNumber; Type: DOMAIN; Schema: sdNumber; Owner: postgres
--

CREATE DOMAIN "sdNumber"."sdSequenceNumber" AS integer NOT NULL;


ALTER DOMAIN "sdNumber"."sdSequenceNumber" OWNER TO postgres;

--
-- Name: DOMAIN "sdSequenceNumber"; Type: COMMENT; Schema: sdNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdNumber"."sdSequenceNumber" IS 'contains all sequence type numbers';


--
-- Name: TransactionNumber; Type: DOMAIN; Schema: sdOrdinalNumber; Owner: postgres
--

CREATE DOMAIN "sdOrdinalNumber"."TransactionNumber" AS integer NOT NULL;


ALTER DOMAIN "sdOrdinalNumber"."TransactionNumber" OWNER TO postgres;

--
-- Name: DOMAIN "TransactionNumber"; Type: COMMENT; Schema: sdOrdinalNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdOrdinalNumber"."TransactionNumber" IS 'for transaction numbers';


--
-- Name: GrouplProjectNameString; Type: DOMAIN; Schema: sdProjectString; Owner: postgres
--

CREATE DOMAIN "sdProjectString"."GrouplProjectNameString" AS character varying(20);


ALTER DOMAIN "sdProjectString"."GrouplProjectNameString" OWNER TO postgres;

--
-- Name: DOMAIN "GrouplProjectNameString"; Type: COMMENT; Schema: sdProjectString; Owner: postgres
--

COMMENT ON DOMAIN "sdProjectString"."GrouplProjectNameString" IS 'for the group project name';


--
-- Name: IndividualProjectNameString; Type: DOMAIN; Schema: sdProjectString; Owner: postgres
--

CREATE DOMAIN "sdProjectString"."IndividualProjectNameString" AS character varying(60);


ALTER DOMAIN "sdProjectString"."IndividualProjectNameString" OWNER TO postgres;

--
-- Name: DOMAIN "IndividualProjectNameString"; Type: COMMENT; Schema: sdProjectString; Owner: postgres
--

COMMENT ON DOMAIN "sdProjectString"."IndividualProjectNameString" IS 'for the individual project name';


--
-- Name: LineItemNumber; Type: DOMAIN; Schema: sdSequenceNumber; Owner: postgres
--

CREATE DOMAIN "sdSequenceNumber"."LineItemNumber" AS integer NOT NULL;


ALTER DOMAIN "sdSequenceNumber"."LineItemNumber" OWNER TO postgres;

--
-- Name: DOMAIN "LineItemNumber"; Type: COMMENT; Schema: sdSequenceNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdSequenceNumber"."LineItemNumber" IS 'for line item numbers';


--
-- Name: StockIdNumber; Type: DOMAIN; Schema: sdSequenceNumber; Owner: postgres
--

CREATE DOMAIN "sdSequenceNumber"."StockIdNumber" AS integer NOT NULL;


ALTER DOMAIN "sdSequenceNumber"."StockIdNumber" OWNER TO postgres;

--
-- Name: DOMAIN "StockIdNumber"; Type: COMMENT; Schema: sdSequenceNumber; Owner: postgres
--

COMMENT ON DOMAIN "sdSequenceNumber"."StockIdNumber" IS 'for stock id numbers';


--
-- Name: InvoiceNumber; Type: DOMAIN; Schema: sdShortTextString; Owner: postgres
--

CREATE DOMAIN "sdShortTextString"."InvoiceNumber" AS character varying(8);


ALTER DOMAIN "sdShortTextString"."InvoiceNumber" OWNER TO postgres;

--
-- Name: DOMAIN "InvoiceNumber"; Type: COMMENT; Schema: sdShortTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdShortTextString"."InvoiceNumber" IS 'for invoice numbers that may contain characters';


--
-- Name: StockCode; Type: DOMAIN; Schema: sdShortTextString; Owner: postgres
--

CREATE DOMAIN "sdShortTextString"."StockCode" AS character varying(50);


ALTER DOMAIN "sdShortTextString"."StockCode" OWNER TO postgres;

--
-- Name: DOMAIN "StockCode"; Type: COMMENT; Schema: sdShortTextString; Owner: postgres
--

COMMENT ON DOMAIN "sdShortTextString"."StockCode" IS 'for stock codes that may contain characters';


--
-- Name: sdAddressesString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdAddressesString" AS character varying(20);


ALTER DOMAIN "sdString"."sdAddressesString" OWNER TO postgres;

--
-- Name: DOMAIN "sdAddressesString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdAddressesString" IS 'contains all address related strings';


--
-- Name: sdAudit; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdAudit" AS character(1);


ALTER DOMAIN "sdString"."sdAudit" OWNER TO postgres;

--
-- Name: DOMAIN "sdAudit"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdAudit" IS 'contains all audit action strings';


--
-- Name: sdBusinessComponentString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdBusinessComponentString" AS character varying(20);


ALTER DOMAIN "sdString"."sdBusinessComponentString" OWNER TO postgres;

--
-- Name: DOMAIN "sdBusinessComponentString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdBusinessComponentString" IS 'contains all business component strings';


--
-- Name: sdCountryStringVariant; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdCountryStringVariant" AS character varying(20);


ALTER DOMAIN "sdString"."sdCountryStringVariant" OWNER TO postgres;

--
-- Name: DOMAIN "sdCountryStringVariant"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdCountryStringVariant" IS 'contains all country variants';


--
-- Name: sdLongTextString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdLongTextString" AS character varying(200);


ALTER DOMAIN "sdString"."sdLongTextString" OWNER TO postgres;

--
-- Name: DOMAIN "sdLongTextString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdLongTextString" IS 'contains all long text strings';


--
-- Name: sdMarketingTextString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdMarketingTextString" AS character varying(25);


ALTER DOMAIN "sdString"."sdMarketingTextString" OWNER TO postgres;

--
-- Name: DOMAIN "sdMarketingTextString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdMarketingTextString" IS 'contains all marketing related strings';


--
-- Name: sdNameString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdNameString" AS character varying(50) NOT NULL;


ALTER DOMAIN "sdString"."sdNameString" OWNER TO postgres;

--
-- Name: DOMAIN "sdNameString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdNameString" IS 'contains all person name strings';


--
-- Name: sdProjectString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdProjectString" AS character varying(50);


ALTER DOMAIN "sdString"."sdProjectString" OWNER TO postgres;

--
-- Name: DOMAIN "sdProjectString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdProjectString" IS 'contains all project related strings';


--
-- Name: sdShortTextString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdShortTextString" AS character varying(50);


ALTER DOMAIN "sdString"."sdShortTextString" OWNER TO postgres;

--
-- Name: DOMAIN "sdShortTextString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdShortTextString" IS 'contains all short text strings';


--
-- Name: sdTimeString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdTimeString" AS character varying(20);


ALTER DOMAIN "sdString"."sdTimeString" OWNER TO postgres;

--
-- Name: DOMAIN "sdTimeString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdTimeString" IS 'contains all strings that represent time';


--
-- Name: sdVehicleString; Type: DOMAIN; Schema: sdString; Owner: postgres
--

CREATE DOMAIN "sdString"."sdVehicleString" AS character varying(50);


ALTER DOMAIN "sdString"."sdVehicleString" OWNER TO postgres;

--
-- Name: DOMAIN "sdVehicleString"; Type: COMMENT; Schema: sdString; Owner: postgres
--

COMMENT ON DOMAIN "sdString"."sdVehicleString" IS 'contains all vehicle strings';


--
-- Name: ClassTimeString; Type: DOMAIN; Schema: sdTimeString; Owner: postgres
--

CREATE DOMAIN "sdTimeString"."ClassTimeString" AS character(5);


ALTER DOMAIN "sdTimeString"."ClassTimeString" OWNER TO postgres;

--
-- Name: DOMAIN "ClassTimeString"; Type: COMMENT; Schema: sdTimeString; Owner: postgres
--

COMMENT ON DOMAIN "sdTimeString"."ClassTimeString" IS 'for representing class time as a string';


--
-- Name: VehicleColor; Type: DOMAIN; Schema: sdVehicleString; Owner: postgres
--

CREATE DOMAIN "sdVehicleString"."VehicleColor" AS character varying(20);


ALTER DOMAIN "sdVehicleString"."VehicleColor" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleColor"; Type: COMMENT; Schema: sdVehicleString; Owner: postgres
--

COMMENT ON DOMAIN "sdVehicleString"."VehicleColor" IS 'for the color of a vehicle';


--
-- Name: VehicleIdentifier; Type: DOMAIN; Schema: sdVehicleString; Owner: postgres
--

CREATE DOMAIN "sdVehicleString"."VehicleIdentifier" AS character varying(150);


ALTER DOMAIN "sdVehicleString"."VehicleIdentifier" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleIdentifier"; Type: COMMENT; Schema: sdVehicleString; Owner: postgres
--

COMMENT ON DOMAIN "sdVehicleString"."VehicleIdentifier" IS 'for Vehicle Identification Numbers';


--
-- Name: VehicleMakeString; Type: DOMAIN; Schema: sdVehicleString; Owner: postgres
--

CREATE DOMAIN "sdVehicleString"."VehicleMakeString" AS character varying(30);


ALTER DOMAIN "sdVehicleString"."VehicleMakeString" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleMakeString"; Type: COMMENT; Schema: sdVehicleString; Owner: postgres
--

COMMENT ON DOMAIN "sdVehicleString"."VehicleMakeString" IS 'for vehicle makes';


--
-- Name: VehicleManufacturerMarketingType; Type: DOMAIN; Schema: sdVehicleString; Owner: postgres
--

CREATE DOMAIN "sdVehicleString"."VehicleManufacturerMarketingType" AS character varying(25);


ALTER DOMAIN "sdVehicleString"."VehicleManufacturerMarketingType" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleManufacturerMarketingType"; Type: COMMENT; Schema: sdVehicleString; Owner: postgres
--

COMMENT ON DOMAIN "sdVehicleString"."VehicleManufacturerMarketingType" IS 'for marketing type descriptions';


--
-- Name: VehicleModelString; Type: DOMAIN; Schema: sdVehicleString; Owner: postgres
--

CREATE DOMAIN "sdVehicleString"."VehicleModelString" AS character varying(35);


ALTER DOMAIN "sdVehicleString"."VehicleModelString" OWNER TO postgres;

--
-- Name: DOMAIN "VehicleModelString"; Type: COMMENT; Schema: sdVehicleString; Owner: postgres
--

COMMENT ON DOMAIN "sdVehicleString"."VehicleModelString" IS 'for vehicle models';


--
-- Name: CreateSha256KeyFromJsonInputHumanResourcesStaff(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputHumanResourcesStaff"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "StaffId", "d"."StaffId", "StaffName", "d"."StaffName", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "HumanResources"."Staff" as "d"
    WHERE "d"."StaffId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputHumanResourcesStaff"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputLocaleCountry(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "CountryId", "d"."CountryId", "CountryISO3", "d"."CountryISO3", "CountryName", "d"."CountryName", "CountryISO2", "d"."CountryISO2", "SalesRegion", "d"."SalesRegion", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Locale"."Country" as "d"
    WHERE "d"."CountryId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputProductionManufacturerModel(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerModel"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "ManufacturerModelId", "d"."ManufacturerModelId", "ManufacturerVehicleMakeId", "d"."ManufacturerVehicleMakeId", "ManufacturerModelName", "d"."ManufacturerModelName", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Production"."ManufacturerModel" as "d"
    WHERE "d"."ManufacturerModelId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerModel"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputProductionManufacturerVehicleMake(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleMake"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "ManufacturerVehicleMakeId", "d"."ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "d"."ManufacturerVehicleMakeName", "CountryId", "d"."CountryId", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Production"."ManufacturerVehicleMake" as "d"
    WHERE "d"."ManufacturerVehicleMakeId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleMake"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputProductionManufacturerVehicleStock(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleStock"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "ManufacturerVehicleStockId", "d"."ManufacturerVehicleStockId", "StockCode", "d"."StockCode", "ModelId", "d"."ModelId", "Cost", "d"."Cost", "RepairsCharge", "d"."RepairsCharge", "PartsCharge", "d"."PartsCharge", "DeliveryCharge", "d"."DeliveryCharge", "IsPremiumRoadHandlingPackage", "d"."IsPremiumRoadHandlingPackage", "VehicleColor", "d"."VehicleColor", "PurchaseDate", "d"."PurchaseDate", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Production"."ManufacturerVehicleStock" as "d"
    WHERE "d"."ManufacturerVehicleStockId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleStock"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputSalesCustomer(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesCustomer"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "CustomerId", "d"."CustomerId", "CustomerName", "d"."CustomerName", "CustomerAddress1", "d"."CustomerAddress1", "CustomerTown", "d"."CustomerTown", "CountryId", "d"."CountryId", "IsCustomerReseller", "d"."IsCustomerReseller", "IsCustomerCreditRisk", "d"."IsCustomerCreditRisk", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Sales"."Customer" as "d"
    WHERE "d"."CustomerId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesCustomer"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputSalesSalesOrderVehicle(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicle"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "SalesOrderVehicleId", "d"."SalesOrderVehicleId", "CustomerId", "d"."CustomerId", "StaffId", "d"."StaffId", "InvoiceNumber", "d"."InvoiceNumber", "TotalSalePrice", "d"."TotalSalePrice", "SaleDate", "d"."SaleDate", "CategoryDescription", "d"."CategoryDescription", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Sales"."SalesOrderVehicle" as "d"
    WHERE "d"."SalesOrderVehicleId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicle"(pky integer) OWNER TO postgres;

--
-- Name: CreateSha256KeyFromJsonInputSalesSalesOrderVehicleDetail(integer); Type: FUNCTION; Schema: Hashing; Owner: postgres
--

CREATE FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicleDetail"(pky integer) RETURNS bytea
    LANGUAGE plpgsql
    AS $$
DECLARE
    column_output_in_json_including_null_values JSONB;
BEGIN
    SELECT jsonb_build_object(
      "SalesOrderVehicleDetailId", "d"."SalesOrderVehicleDetailId", "SalesOrderVehicleId", "d"."SalesOrderVehicleId", "LineItemNumber", "d"."LineItemNumber", "ManufacturerVehicleStockId", "d"."ManufacturerVehicleStockId", "SalePrice", "d"."SalePrice", "LineItemDiscount", "d"."LineItemDiscount", "DerivedDiscountedSalePrice", "d"."DerivedDiscountedSalePrice", "TransactionNumber", "d"."TransactionNumber", "Note", "d"."Note", "UserAuthorizationId", "d"."UserAuthorizationId", "SysStartTime", "d"."SysStartTime", "SysEndTime", "d"."SysEndTime", "FireAuditTrigger", "d"."FireAuditTrigger"
    )::TEXT
    INTO column_output_in_json_including_null_values
    FROM "Sales"."SalesOrderVehicleDetail" as "d"
    WHERE "d"."SalesOrderVehicleDetailId" = pky;

    RETURN encode(digest(column_output_in_json_including_null_values::text, 'sha256'), 'hex')::BYTEA;
END;
$$;


ALTER FUNCTION "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicleDetail"(pky integer) OWNER TO postgres;

--
-- Name: funcDeleteStaffHistory(); Type: FUNCTION; Schema: HumanResources; Owner: postgres
--

CREATE FUNCTION "HumanResources"."funcDeleteStaffHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."HumanResourcesStaffHistory"
    (
      "StaffId", "StaffName", "ManagerId", "Department", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."StaffId", old."StaffName", old."ManagerId", old."Department",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "HumanResources"."funcDeleteStaffHistory"() OWNER TO postgres;

--
-- Name: funcInsertStaffHistory(); Type: FUNCTION; Schema: HumanResources; Owner: postgres
--

CREATE FUNCTION "HumanResources"."funcInsertStaffHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "HumanResources"."Staff"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputHumanResourcesStaff"(NEW."StaffId")
  where "StaffId" = new."StaffId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "HumanResources"."funcInsertStaffHistory"() OWNER TO postgres;

--
-- Name: funcUpdateStaffHistory(); Type: FUNCTION; Schema: HumanResources; Owner: postgres
--

CREATE FUNCTION "HumanResources"."funcUpdateStaffHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."HumanResourcesStaffHistory"
    (
      "StaffId", "StaffName", "ManagerId", "Department", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."StaffId", old."StaffName", old."ManagerId", old."Department",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "HumanResources"."Staff"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."StaffId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "StaffId" = new."StaffId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "HumanResources"."funcUpdateStaffHistory"() OWNER TO postgres;

--
-- Name: funcDeleteCountryHistory(); Type: FUNCTION; Schema: Locale; Owner: postgres
--

CREATE FUNCTION "Locale"."funcDeleteCountryHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."LocaleCountryHistory"
    (
      "CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."CountryId", old."CountryISO3", old."CountryName", old."CountryISO2", old."SalesRegion",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Locale"."funcDeleteCountryHistory"() OWNER TO postgres;

--
-- Name: funcInsertCountryHistory(); Type: FUNCTION; Schema: Locale; Owner: postgres
--

CREATE FUNCTION "Locale"."funcInsertCountryHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Locale"."Country"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."CountryId")
  where "CountryId" = new."CountryId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Locale"."funcInsertCountryHistory"() OWNER TO postgres;

--
-- Name: funcUpdateCountryHistory(); Type: FUNCTION; Schema: Locale; Owner: postgres
--

CREATE FUNCTION "Locale"."funcUpdateCountryHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."LocaleCountryHistory"
    (
      "CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."CountryId", old."CountryISO3", old."CountryName", old."CountryISO2", old."SalesRegion",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Locale"."Country"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."CountryId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "CountryId" = new."CountryId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Locale"."funcUpdateCountryHistory"() OWNER TO postgres;

--
-- Name: funcDeleteManufacturerModelHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcDeleteManufacturerModelHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."ProductionManufacturerModelHistory"
    (
      "ManufacturerModelId", "ManufacturerVehicleMakeId", "ManufacturerModelName", "ManufacturerModelVariant", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerModelId", old."ManufacturerVehicleMakeId", old."ManufacturerModelName", old."ManufacturerModelVariant",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcDeleteManufacturerModelHistory"() OWNER TO postgres;

--
-- Name: funcDeleteManufacturerVehicleMakeHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcDeleteManufacturerVehicleMakeHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."ProductionManufacturerVehicleMakeHistory"
    (
      "ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "MarketingType", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerVehicleMakeId", old."ManufacturerVehicleMakeName", old."CountryId", old."MarketingType",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcDeleteManufacturerVehicleMakeHistory"() OWNER TO postgres;

--
-- Name: funcDeleteManufacturerVehicleStockHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcDeleteManufacturerVehicleStockHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."ProductionManufacturerVehicleStockHistory"
    (
      "ManufacturerVehicleStockId", "StockCode", "ModelId", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "PurchaseDate", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerVehicleStockId", old."StockCode", old."ModelId", old."Cost", old."RepairsCharge", old."PartsCharge", old."DeliveryCharge", old."IsPremiumRoadHandlingPackage", old."VehicleColor", old."CustomerComment", old."PurchaseDate",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcDeleteManufacturerVehicleStockHistory"() OWNER TO postgres;

--
-- Name: funcInsertManufacturerModelHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcInsertManufacturerModelHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Production"."ManufacturerModel"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerModel"(NEW."ManufacturerModelId")
  where "ManufacturerModelId" = new."ManufacturerModelId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcInsertManufacturerModelHistory"() OWNER TO postgres;

--
-- Name: funcInsertManufacturerVehicleMakeHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcInsertManufacturerVehicleMakeHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Production"."ManufacturerVehicleMake"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleMake"(NEW."ManufacturerVehicleMakeId")
  where "ManufacturerVehicleMakeId" = new."ManufacturerVehicleMakeId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcInsertManufacturerVehicleMakeHistory"() OWNER TO postgres;

--
-- Name: funcInsertManufacturerVehicleStockHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcInsertManufacturerVehicleStockHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Production"."ManufacturerVehicleStock"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputProductionManufacturerVehicleStock"(NEW."ManufacturerVehicleStockId")
  where "ManufacturerVehicleStockId" = new."ManufacturerVehicleStockId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcInsertManufacturerVehicleStockHistory"() OWNER TO postgres;

--
-- Name: funcUpdateManufacturerModelHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcUpdateManufacturerModelHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."ProductionManufacturerModelHistory"
    (
      "ManufacturerModelId", "ManufacturerVehicleMakeId", "ManufacturerModelName", "ManufacturerModelVariant", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerModelId", old."ManufacturerVehicleMakeId", old."ManufacturerModelName", old."ManufacturerModelVariant",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Production"."ManufacturerModel"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."ManufacturerModelId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "ManufacturerModelId" = new."ManufacturerModelId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcUpdateManufacturerModelHistory"() OWNER TO postgres;

--
-- Name: funcUpdateManufacturerVehicleMakeHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcUpdateManufacturerVehicleMakeHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."ProductionManufacturerVehicleMakeHistory"
    (
      "ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "MarketingType", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerVehicleMakeId", old."ManufacturerVehicleMakeName", old."CountryId", old."MarketingType",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Production"."ManufacturerVehicleMake"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."ManufacturerVehicleMakeId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "ManufacturerVehicleMakeId" = new."ManufacturerVehicleMakeId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcUpdateManufacturerVehicleMakeHistory"() OWNER TO postgres;

--
-- Name: funcUpdateManufacturerVehicleStockHistory(); Type: FUNCTION; Schema: Production; Owner: postgres
--

CREATE FUNCTION "Production"."funcUpdateManufacturerVehicleStockHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."ProductionManufacturerVehicleStockHistory"
    (
      "ManufacturerVehicleStockId", "StockCode", "ModelId", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "PurchaseDate", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."ManufacturerVehicleStockId", old."StockCode", old."ModelId", old."Cost", old."RepairsCharge", old."PartsCharge", old."DeliveryCharge", old."IsPremiumRoadHandlingPackage", old."VehicleColor", old."CustomerComment", old."PurchaseDate",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Production"."ManufacturerVehicleStock"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."ManufacturerVehicleStockId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "ManufacturerVehicleStockId" = new."ManufacturerVehicleStockId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Production"."funcUpdateManufacturerVehicleStockHistory"() OWNER TO postgres;

--
-- Name: funcDeleteCustomerHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcDeleteCustomerHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."SalesCustomerHistory"
    (
      "CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."CustomerId", old."CustomerName", old."CustomerAddress1", old."CustomerAddress2", old."CustomerTown", old."CustomerPostalCode", old."CountryId", old."IsCustomerReseller", old."IsCustomerCreditRisk", old."SpendCapacity",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcDeleteCustomerHistory"() OWNER TO postgres;

--
-- Name: funcDeleteSalesOrderVehicleDetailHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcDeleteSalesOrderVehicleDetailHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."SalesSalesOrderVehicleDetailHistory"
    (
      "SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "ManufacturerVehicleStockId", "SalePrice", "LineItemDiscount", "DerivedDiscountedSalePrice", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
       old."SalesOrderVehicleDetailId",  old."SalesOrderVehicleId", old."LineItemNumber",  old."SalePrice", old."LineItemDiscount",  old."DerivedDiscountedSalePrice", old."ManufacturerVehicleStockId",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcDeleteSalesOrderVehicleDetailHistory"() OWNER TO postgres;

--
-- Name: funcDeleteSalesOrderVehicleHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcDeleteSalesOrderVehicleHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    INSERT INTO "Audit"."SalesSalesOrderVehicleHistory"
    (
      "SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "CategoryDescription", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."SalesOrderVehicleId", old."CustomerId", old."StaffId", old."InvoiceNumber", old."TotalSalePrice", old."SaleDate", old."CategoryDescription",
      old."TransactionNumber",
      'Row was deleted',
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      old."FireAuditTrigger",
      now(),
      'D',
      'Y'
    );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcDeleteSalesOrderVehicleHistory"() OWNER TO postgres;

--
-- Name: funcInsertCustomerHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcInsertCustomerHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Sales"."Customer"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputSalesCustomer"(NEW."CustomerId")
  where "CustomerId" = new."CustomerId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcInsertCustomerHistory"() OWNER TO postgres;

--
-- Name: funcInsertSalesOrderVehicleDetailHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcInsertSalesOrderVehicleDetailHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Sales"."SalesOrderVehicleDetail"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicleDetail"(NEW."SalesOrderVehicleDetailId")
  where "SalesOrderVehicleDetailId" = new."SalesOrderVehicleDetailId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcInsertSalesOrderVehicleDetailHistory"() OWNER TO postgres;

--
-- Name: funcInsertSalesOrderVehicleHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcInsertSalesOrderVehicleHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
  IF NEW."TransactionNumber" = 1 THEN
  NEW."PriorRowLevelHashKey" := NULL;
  NEW."Note" := 'Row Inserted';
  NEW."FireAuditTrigger" := 'N';

  update "Sales"."SalesOrderVehicle"
  set "RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputSalesSalesOrderVehicle"(NEW."SalesOrderVehicleId")
  where "SalesOrderVehicleId" = new."SalesOrderVehicleId";
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcInsertSalesOrderVehicleHistory"() OWNER TO postgres;

--
-- Name: funcUpdateCustomerHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcUpdateCustomerHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."SalesCustomerHistory"
    (
      "CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."CustomerId", old."CustomerName", old."CustomerAddress1", old."CustomerAddress2", old."CustomerTown", old."CustomerPostalCode", old."CountryId", old."IsCustomerReseller", old."IsCustomerCreditRisk", old."SpendCapacity",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Sales"."Customer"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."CustomerId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "CustomerId" = new."CustomerId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcUpdateCustomerHistory"() OWNER TO postgres;

--
-- Name: funcUpdateSalesOrderVehicleCategoryDescription(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcUpdateSalesOrderVehicleCategoryDescription"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."CategoryDescription" = (CASE
            WHEN new."TotalSalePrice" >= 100001.00 THEN 'Very High'
            WHEN new."TotalSalePrice" BETWEEN 75001.00 AND 100000.00 THEN 'High'
            WHEN new."TotalSalePrice" BETWEEN 50001.00 AND 75000.00 THEN 'Medium'
            WHEN new."TotalSalePrice" BETWEEN 25001.00 AND 50000.00 THEN 'Low'
            WHEN new."TotalSalePrice" BETWEEN 150001.00 AND 250000.00 THEN 'Exceptional'
            WHEN new."TotalSalePrice" BETWEEN 100001.00 AND 150000.00 THEN 'Very High'
            WHEN new."TotalSalePrice" BETWEEN 100.00 AND 25000.00 THEN 'Very Low'
            ELSE 'Unknown'
        end);
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcUpdateSalesOrderVehicleCategoryDescription"() OWNER TO postgres;

--
-- Name: funcUpdateSalesOrderVehicleDetailDerivedDiscountedSalePrice(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcUpdateSalesOrderVehicleDetailDerivedDiscountedSalePrice"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."DerivedDiscountedSalePrice" = NEW."SalePrice" - NEW."LineItemDiscount";
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcUpdateSalesOrderVehicleDetailDerivedDiscountedSalePrice"() OWNER TO postgres;

--
-- Name: funcUpdateSalesOrderVehicleDetailHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcUpdateSalesOrderVehicleDetailHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."SalesSalesOrderVehicleDetailHistory"
    (
      "SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "ManufacturerVehicleStockId", "SalePrice", "LineItemDiscount", "DerivedDiscountedSalePrice", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
       old."SalesOrderVehicleDetailId",  old."SalesOrderVehicleId", old."LineItemNumber",  old."SalePrice", old."LineItemDiscount",  old."DerivedDiscountedSalePrice", old."ManufacturerVehicleStockId",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Sales"."SalesOrderVehicleDetail"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."SalesOrderVehicleDetailId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "SalesOrderVehicleDetailId" = new."SalesOrderVehicleDetailId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcUpdateSalesOrderVehicleDetailHistory"() OWNER TO postgres;

--
-- Name: funcUpdateSalesOrderVehicleHistory(); Type: FUNCTION; Schema: Sales; Owner: postgres
--

CREATE FUNCTION "Sales"."funcUpdateSalesOrderVehicleHistory"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    if (new."FireAuditTrigger" = 'Y') then
    INSERT INTO "Audit"."SalesSalesOrderVehicleHistory"
    (
      "SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "CategoryDescription", "TransactionNumber", "Note", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "IsDeleted"
    )
    VALUES(
      old."SalesOrderVehicleId", old."CustomerId", old."StaffId", old."InvoiceNumber", old."TotalSalePrice", old."SaleDate", old."CategoryDescription",
      old."TransactionNumber",
      coalesce(old."Note", concat('No Message Transaction Number: ', old."TransactionNumber")),
      old."UserAuthorizationId",
      old."SysStartTime",
      now(),
      old."RowLevelHashKey",
      old."PriorRowLevelHashKey",
      new."FireAuditTrigger",
      new."SysStartTime",
      'U',
      'N'
    );
    update "Sales"."SalesOrderVehicle"
    SET
    "TransactionNumber" = old."TransactionNumber" + 1,
    "SysStartTime" = now(),
	"RowLevelHashKey" = "Hashing"."CreateSha256KeyFromJsonInputLocaleCountry"(NEW."SalesOrderVehicleId"),
	"PriorRowLevelHashKey" = old."RowLevelHashKey",
	"Note" = coalesce(new."Note", 'Row updated'),
	"FireAuditTrigger" = 'N'
	where "SalesOrderVehicleId" = new."SalesOrderVehicleId";
    END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "Sales"."funcUpdateSalesOrderVehicleHistory"() OWNER TO postgres;

--
-- Name: viewFunc-FindAllTransactionsViewByTablePkyOfHumanResourcesStaff(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfHumanResourcesStaff"(pky integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'CREATE OR REPLACE VIEW "vw_FindAllTransactionsByTablePkyOHumanResourcesStaff" AS
        SELECT ''Current'' AS "TransactionType",
               NULL AS "AuditDateTimeStamp",
               NULL AS "DBAction",
               "d"."StaffId", "d"."StaffName", "d"."ManagerId", "d"."Department", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "HumanResources"."Staff" AS "d"
        WHERE "d"."StaffId" = ' || pky || '
        UNION ALL
        SELECT ''History'' AS "TransactionType",
               "d"."AuditDateTimeStamp",
               "d"."DBAction",
               "d"."StaffId", "d"."StaffName", "d"."ManagerId", "d"."Department", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Audit"."HumanResourcesStaffHistory" as "d"
        WHERE "d"."StaffId" = ' || pky;
END;
$$;


ALTER FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfHumanResourcesStaff"(pky integer) OWNER TO postgres;

--
-- Name: viewFunc-FindAllTransactionsViewByTablePkyOfLocaleCountry(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfLocaleCountry"(pky integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'CREATE OR REPLACE VIEW "vw_FindAllTransactionsByTablePkyOLocaleCountry" AS
        SELECT ''Current'' AS "TransactionType",
               NULL AS "AuditDateTimeStamp",
               NULL AS "DBAction",
               "d"."CountryId", "d"."CountryISO3", "d"."CountryName", "d"."CountryISO2", "d"."SalesRegion", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Locale"."Country" AS "d"
        WHERE "d"."CountryId" = ' || pky || '
        UNION ALL
        SELECT ''History'' AS "TransactionType",
               "d"."AuditDateTimeStamp",
               "d"."DBAction",
               "d"."CountryId", "d"."CountryISO3", "d"."CountryName", "d"."CountryISO2", "d"."SalesRegion", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Audit"."LocaleCountryHistory" as "d"
        WHERE "d"."CountryId" = ' || pky;
END;
$$;


ALTER FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfLocaleCountry"(pky integer) OWNER TO postgres;

--
-- Name: viewFunc-FindAllTransactionsViewByTablePkyOfProductionManufactu(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfProductionManufactu"(pky integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'CREATE OR REPLACE VIEW "vw_FindAllTransactionsByTablePkyOProductionManufacturerVehicleStock" AS
        SELECT ''Current'' AS "TransactionType",
               NULL AS "AuditDateTimeStamp",
               NULL AS "DBAction",
               "d"."ManufacturerVehicleStockId", "d"."StockCode", "d"."ModelId", "d"."Cost", "d"."RepairsCharge", "d"."PartsCharge", "d"."DeliveryCharge", "d"."IsPremiumRoadHandlingPackage", "d"."VehicleColor", "d"."CustomerComment", "d"."PurchaseDate", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Production"."ManufacturerVehicleStock" AS "d"
        WHERE "d"."ManufacturerVehicleStockId" = ' || pky || '
        UNION ALL
        SELECT ''History'' AS "TransactionType",
               "d"."AuditDateTimeStamp",
               "d"."DBAction",
               "d"."ManufacturerVehicleStockId", "d"."StockCode", "d"."ModelId", "d"."Cost", "d"."RepairsCharge", "d"."PartsCharge", "d"."DeliveryCharge", "d"."IsPremiumRoadHandlingPackage", "d"."VehicleColor", "d"."CustomerComment", "d"."PurchaseDate", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Audit"."ProductionManufacturerVehicleStockHistory" as "d"
        WHERE "d"."ManufacturerVehicleStockId" = ' || pky;
END;
$$;


ALTER FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfProductionManufactu"(pky integer) OWNER TO postgres;

--
-- Name: viewFunc-FindAllTransactionsViewByTablePkyOfSalesCustomer(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfSalesCustomer"(pky integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'CREATE OR REPLACE VIEW "vw_FindAllTransactionsByTablePkyOSalesCustomer" AS
        SELECT ''Current'' AS "TransactionType",
               NULL AS "AuditDateTimeStamp",
               NULL AS "DBAction",
               "d"."CustomerId", "d"."CustomerName", "d"."CustomerAddress1", "d"."CustomerAddress2", "d"."CustomerTown", "d"."CustomerPostalCode", "d"."CountryId", "d"."IsCustomerReseller", "d"."IsCustomerCreditRisk", "d"."SpendCapacity", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Sales"."Customer" AS "d"
        WHERE "d"."CustomerId" = ' || pky || '
        UNION ALL
        SELECT ''History'' AS "TransactionType",
               "d"."AuditDateTimeStamp",
               "d"."DBAction",
               "d"."CustomerId", "d"."CustomerName", "d"."CustomerAddress1", "d"."CustomerAddress2", "d"."CustomerTown", "d"."CustomerPostalCode", "d"."CountryId", "d"."IsCustomerReseller", "d"."IsCustomerCreditRisk", "d"."SpendCapacity", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Audit"."SalesCustomerHistory" as "d"
        WHERE "d"."CustomerId" = ' || pky;
END;
$$;


ALTER FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfSalesCustomer"(pky integer) OWNER TO postgres;

--
-- Name: viewFunc-FindAllTransactionsViewByTablePkyOfSalesSalesOrderVehi(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfSalesSalesOrderVehi"(pky integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'CREATE OR REPLACE VIEW "vw_FindAllTransactionsByTablePkyOSalesSalesOrderVehicleDetail" AS
        SELECT ''Current'' AS "TransactionType",
               NULL AS "AuditDateTimeStamp",
               NULL AS "DBAction",
               "d"."SalesOrderVehicleDetailId", "d"."SalesOrderVehicleId", "d"."LineItemNumber", "d"."ManufacturerVehicleStockId", "d"."SalePrice", "d"."LineItemDiscount", "d"."DerivedDiscountedSalePrice", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Sales"."SalesOrderVehicleDetail" AS "d"
        WHERE "d"."SalesOrderVehicleDetailId" = ' || pky || '
        UNION ALL
        SELECT ''History'' AS "TransactionType",
               "d"."AuditDateTimeStamp",
               "d"."DBAction",
               "d"."SalesOrderVehicleDetailId", "d"."SalesOrderVehicleId", "d"."LineItemNumber", "d"."ManufacturerVehicleStockId", "d"."SalePrice", "d"."LineItemDiscount", "d"."DerivedDiscountedSalePrice", "d"."TransactionNumber", "d"."Note", "d"."UserAuthorizationId", "d"."SysStartTime", "d"."SysEndTime", "d"."RowLevelHashKey", "d"."PriorRowLevelHashKey", "d"."FireAuditTrigger"
        FROM "Audit"."SalesSalesOrderVehicleDetailHistory" as "d"
        WHERE "d"."SalesOrderVehicleDetailId" = ' || pky;
END;
$$;


ALTER FUNCTION public."viewFunc-FindAllTransactionsViewByTablePkyOfSalesSalesOrderVehi"(pky integer) OWNER TO postgres;

--
-- Name: Audit_HumanResourcesStaffHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_HumanResourcesStaffHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_HumanResourcesStaffHistory_Id" OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: HumanResourcesStaffHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."HumanResourcesStaffHistory" (
    "StaffId" integer NOT NULL,
    "StaffName" character varying(60) NOT NULL,
    "Department" character varying(15),
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "ManagerId" integer,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "StaffHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_HumanResourcesStaffHistory_Id"'::regclass) NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_Audit_HumanResourcesStaffHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."HumanResourcesStaffHistory" OWNER TO postgres;

--
-- Name: TABLE "HumanResourcesStaffHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."HumanResourcesStaffHistory" IS 'The audit history table for Staff';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."StaffId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."StaffId" IS 'A unique identifier for staff members';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."StaffName"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."StaffName" IS 'The full name of a staff member';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."Department"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."Department" IS 'The department name a staff member works in';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."ManagerId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."ManagerId" IS 'The ID of a staff member that supervises an employee';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."StaffHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."StaffHistoryId" IS 'A unique identifier for audit entries in HumanResourcesStaffHistory';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "HumanResourcesStaffHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."HumanResourcesStaffHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_LocaleCountryHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_LocaleCountryHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_LocaleCountryHistory_Id" OWNER TO postgres;

--
-- Name: LocaleCountryHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."LocaleCountryHistory" (
    "CountryId" integer NOT NULL,
    "CountryISO3" character(3) NOT NULL,
    "CountryName" character varying(50) NOT NULL,
    "CountryISO2" character varying(2) NOT NULL,
    "SalesRegion" character varying(20) NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "LocaleCountryHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_LocaleCountryHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_Audit_LocaleCountryHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."LocaleCountryHistory" OWNER TO postgres;

--
-- Name: TABLE "LocaleCountryHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."LocaleCountryHistory" IS 'The audit history table for Country';


--
-- Name: COLUMN "LocaleCountryHistory"."CountryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "LocaleCountryHistory"."CountryISO3"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."CountryISO3" IS 'The ISO3 format of a country';


--
-- Name: COLUMN "LocaleCountryHistory"."CountryName"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."CountryName" IS 'The name of the country';


--
-- Name: COLUMN "LocaleCountryHistory"."CountryISO2"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."CountryISO2" IS 'The ISO2 format of a country';


--
-- Name: COLUMN "LocaleCountryHistory"."SalesRegion"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."SalesRegion" IS 'The name of the sales region a coutry belongs to';


--
-- Name: COLUMN "LocaleCountryHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "LocaleCountryHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "LocaleCountryHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "LocaleCountryHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "LocaleCountryHistory"."LocaleCountryHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."LocaleCountryHistoryId" IS 'A unique identifier for audit entries in LocaleCountryHistory';


--
-- Name: COLUMN "LocaleCountryHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "LocaleCountryHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "LocaleCountryHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "LocaleCountryHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "LocaleCountryHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "LocaleCountryHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "LocaleCountryHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."LocaleCountryHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_ProductionManufacturerModelHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_ProductionManufacturerModelHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_ProductionManufacturerModelHistory_Id" OWNER TO postgres;

--
-- Name: ProductionManufacturerModelHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."ProductionManufacturerModelHistory" (
    "ManufacturerModelId" integer NOT NULL,
    "ManufacturerModelName" character varying(35) NOT NULL,
    "ManufacturerModelVariant" character varying(35),
    "ManufacturerVehicleMakeId" integer NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "ProductionManufacturerModelHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_ProductionManufacturerModelHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_ProductionManufacturerVehicleModelHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."ProductionManufacturerModelHistory" OWNER TO postgres;

--
-- Name: TABLE "ProductionManufacturerModelHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."ProductionManufacturerModelHistory" IS 'The audit history table for ManufacturerModel';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."ManufacturerModelId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."ManufacturerModelId" IS 'A unique identifier for vehicle models';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."ManufacturerModelName"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."ManufacturerModelName" IS 'The name of a vehicle model';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."ManufacturerModelVariant"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."ManufacturerModelVariant" IS 'The name of a vehicle model variant if applicable';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."ManufacturerVehicleMakeId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."ManufacturerVehicleMakeId" IS 'A unique identifier for vehicle makes';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."ProductionManufacturerModelHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."ProductionManufacturerModelHistoryId" IS 'A unique identifier for audit entries in ProductionManufacturerModelHistory';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "ProductionManufacturerModelHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerModelHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_ProductionManufacturerVehicleMakeHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_ProductionManufacturerVehicleMakeHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_ProductionManufacturerVehicleMakeHistory_Id" OWNER TO postgres;

--
-- Name: ProductionManufacturerVehicleMakeHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."ProductionManufacturerVehicleMakeHistory" (
    "ManufacturerVehicleMakeId" integer NOT NULL,
    "ManufacturerVehicleMakeName" character varying(30) NOT NULL,
    "CountryId" integer NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "ProductionManufacturerVehicleMakeHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_ProductionManufacturerVehicleMakeHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    "MarketingType" character varying(25),
    CONSTRAINT "CK_Audit_ProductionManufacturerVehicleHistory_AuditDateTimeStam" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."ProductionManufacturerVehicleMakeHistory" OWNER TO postgres;

--
-- Name: TABLE "ProductionManufacturerVehicleMakeHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."ProductionManufacturerVehicleMakeHistory" IS 'The audit history table for ManufacturerVehicleMake';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."ManufacturerVehicleMakeId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."ManufacturerVehicleMakeId" IS 'A unique identifier for vehicle makes';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."ManufacturerVehicleMakeName"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."ManufacturerVehicleMakeName" IS 'The name of a vehicles make';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."CountryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."ProductionManufacturerVehicleMakeHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."ProductionManufacturerVehicleMakeHistoryId" IS 'A unique identifier for audit entries in ProductionManufacturerVehicleMakeHistory';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: COLUMN "ProductionManufacturerVehicleMakeHistory"."MarketingType"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleMakeHistory"."MarketingType" IS 'The marketing type of a vehicle make';


--
-- Name: Audit_ProductionManufacturerVehicleStockHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_ProductionManufacturerVehicleStockHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_ProductionManufacturerVehicleStockHistory_Id" OWNER TO postgres;

--
-- Name: ProductionManufacturerVehicleStockHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."ProductionManufacturerVehicleStockHistory" (
    "ManufacturerVehicleStockId" integer NOT NULL,
    "StockCode" character varying(50) NOT NULL,
    "Cost" numeric(18,2) NOT NULL,
    "RepairsCharge" numeric(18,2) NOT NULL,
    "PartsCharge" numeric(18,2) NOT NULL,
    "DeliveryCharge" numeric(18,2) NOT NULL,
    "IsPremiumRoadHandlingPackage" integer NOT NULL,
    "VehicleColor" character varying(20) NOT NULL,
    "CustomerComment" character varying(200),
    "ModelId" integer NOT NULL,
    "PurchaseDate" date NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "ProductionManufacturerVehicleStockHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_ProductionManufacturerVehicleStockHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_ProductionManufacturerVehicleStockHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."ProductionManufacturerVehicleStockHistory" OWNER TO postgres;

--
-- Name: TABLE "ProductionManufacturerVehicleStockHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."ProductionManufacturerVehicleStockHistory" IS 'The audit history table for ManufacturerVehicleStock';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."ManufacturerVehicleStockId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."ManufacturerVehicleStockId" IS 'A unique identifier for manfacturer vehicle stock';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."StockCode"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."StockCode" IS 'The stock code of a vehicle';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."Cost"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."Cost" IS 'The cost of a vehicle from the manufacturer';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."RepairsCharge"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."RepairsCharge" IS 'The charge for repairs on a vehicle';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."PartsCharge"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."PartsCharge" IS 'The charge for parts on a vehicle';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."DeliveryCharge"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."DeliveryCharge" IS 'The charge for delivery of a vehicle';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."IsPremiumRoadHandlingPackage"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."IsPremiumRoadHandlingPackage" IS 'A flag to determine if a vehicle has a premium road handling package';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."VehicleColor"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."VehicleColor" IS 'The color of the vehicle';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."CustomerComment"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."CustomerComment" IS 'A comment added by a customer';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."ModelId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."ModelId" IS 'A unique identifier for vehicle models';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."PurchaseDate"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."PurchaseDate" IS 'The date of purchase';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."ProductionManufacturerVehicleStockHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."ProductionManufacturerVehicleStockHistoryId" IS 'A unique identifier for audit entries in ProductionManufacturerVehicleStockHistory';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "ProductionManufacturerVehicleStockHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."ProductionManufacturerVehicleStockHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_SalesCustomerHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_SalesCustomerHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_SalesCustomerHistory_Id" OWNER TO postgres;

--
-- Name: SalesCustomerHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."SalesCustomerHistory" (
    "CustomerId" integer NOT NULL,
    "CustomerName" character varying(65) NOT NULL,
    "CustomerAddress1" character varying(60) NOT NULL,
    "CustomerAddress2" character varying(60),
    "CustomerTown" character varying(30) NOT NULL,
    "CustomerPostalCode" character varying(9),
    "CountryId" integer NOT NULL,
    "IsCustomerReseller" integer NOT NULL,
    "IsCustomerCreditRisk" integer NOT NULL,
    "SpendCapacity" character varying(15),
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "SalesCustomerHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_SalesCustomerHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_Audit_SalesSalesCustomerHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."SalesCustomerHistory" OWNER TO postgres;

--
-- Name: TABLE "SalesCustomerHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."SalesCustomerHistory" IS 'The audit history table for Customer';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerId" IS 'A unique identifier for customers';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerName"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerName" IS 'The full name of a customer';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerAddress1"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerAddress1" IS 'The street address of a customer';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerAddress2"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerAddress2" IS 'The extended street address of a customer';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerTown"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerTown" IS 'The town or city a customer resides in';


--
-- Name: COLUMN "SalesCustomerHistory"."CustomerPostalCode"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CustomerPostalCode" IS 'The postal code of a customer if applicable';


--
-- Name: COLUMN "SalesCustomerHistory"."CountryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "SalesCustomerHistory"."IsCustomerReseller"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."IsCustomerReseller" IS 'Flag to determine if a customer is a reseller';


--
-- Name: COLUMN "SalesCustomerHistory"."IsCustomerCreditRisk"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."IsCustomerCreditRisk" IS 'Flag to determine if customer is a credit risk';


--
-- Name: COLUMN "SalesCustomerHistory"."SpendCapacity"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."SpendCapacity" IS 'The spend capacity of a customer';


--
-- Name: COLUMN "SalesCustomerHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "SalesCustomerHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "SalesCustomerHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "SalesCustomerHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "SalesCustomerHistory"."SalesCustomerHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."SalesCustomerHistoryId" IS 'A unique identifier for audit entries in SalesCustomerHistory';


--
-- Name: COLUMN "SalesCustomerHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "SalesCustomerHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "SalesCustomerHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "SalesCustomerHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "SalesCustomerHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "SalesCustomerHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "SalesCustomerHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesCustomerHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_SalesSalesOrderVehicleDetailHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_SalesSalesOrderVehicleDetailHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_SalesSalesOrderVehicleDetailHistory_Id" OWNER TO postgres;

--
-- Name: SalesSalesOrderVehicleDetailHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."SalesSalesOrderVehicleDetailHistory" (
    "SalesOrderVehicleDetailId" integer NOT NULL,
    "SalesOrderVehicleId" integer NOT NULL,
    "LineItemNumber" integer NOT NULL,
    "SalePrice" numeric(18,2) NOT NULL,
    "LineItemDiscount" numeric(18,2) NOT NULL,
    "ManufacturerVehicleStockId" integer NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "SalesSalesOrderVehicleDetailHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_SalesSalesOrderVehicleDetailHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "DerivedDiscountedSalePrice" numeric(18,2),
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    CONSTRAINT "CK_SalesSalesOrderVehicleDetailHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."SalesSalesOrderVehicleDetailHistory" OWNER TO postgres;

--
-- Name: TABLE "SalesSalesOrderVehicleDetailHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."SalesSalesOrderVehicleDetailHistory" IS 'The audit history table for SalesOrderVehicleDetail';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SalesOrderVehicleDetailId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SalesOrderVehicleDetailId" IS 'A unique identifier for SalesSalesOrderVehicleDetailHistory Ids';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SalesOrderVehicleId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SalesOrderVehicleId" IS 'A unique identifier for a purchase';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."LineItemNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."LineItemNumber" IS 'The line item number on the invoice';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SalePrice"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SalePrice" IS 'The sale price of a vehicle';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."LineItemDiscount"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."LineItemDiscount" IS 'The discount of the line item number';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."ManufacturerVehicleStockId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."ManufacturerVehicleStockId" IS 'A unique identifier for manfacturer vehicle stock';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."SalesSalesOrderVehicleDetailHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."SalesSalesOrderVehicleDetailHistoryId" IS 'A unique identifier for audit entries in SalesSalesOrderVehicleDetailHistory';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."DerivedDiscountedSalePrice"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."DerivedDiscountedSalePrice" IS 'The derived discounted sale price of a vehicle';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "SalesSalesOrderVehicleDetailHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleDetailHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: Audit_SalesSalesOrderVehicleHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_SalesSalesOrderVehicleHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_SalesSalesOrderVehicleHistory_Id" OWNER TO postgres;

--
-- Name: SalesSalesOrderVehicleHistory; Type: TABLE; Schema: Audit; Owner: postgres
--

CREATE TABLE "Audit"."SalesSalesOrderVehicleHistory" (
    "SalesOrderVehicleId" integer NOT NULL,
    "CustomerId" integer NOT NULL,
    "StaffId" integer NOT NULL,
    "InvoiceNumber" character varying(8) NOT NULL,
    "TotalSalePrice" numeric(18,2) NOT NULL,
    "SaleDate" date NOT NULL,
    "UserAuthorizationId" integer NOT NULL,
    "SysStartTime" timestamp without time zone,
    "SysEndTime" timestamp without time zone,
    "RowLevelHashKey" bytea,
    "SalesSalesOrderVehicleHistoryId" integer DEFAULT nextval('"SequenceIdInsert"."Audit_SalesSalesOrderVehicleHistory_Id"'::regclass) NOT NULL,
    "Note" character varying(100),
    "IsDeleted" character(1) NOT NULL,
    "TransactionNumber" integer NOT NULL,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) NOT NULL,
    "AuditDateTimeStamp" timestamp without time zone DEFAULT now() NOT NULL,
    "DBAction" character(1) NOT NULL,
    "CategoryDescription" character varying(20) NOT NULL,
    CONSTRAINT "CK_SalesSalesOrderVehicleHistory_DBAction" CHECK ((("DBAction" = 'U'::bpchar) OR ("DBAction" = 'I'::bpchar) OR ("DBAction" = 'D'::bpchar)))
);


ALTER TABLE "Audit"."SalesSalesOrderVehicleHistory" OWNER TO postgres;

--
-- Name: TABLE "SalesSalesOrderVehicleHistory"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON TABLE "Audit"."SalesSalesOrderVehicleHistory" IS 'The audit history table for SalesOrderVehicle';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."SalesOrderVehicleId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."SalesOrderVehicleId" IS 'A unique identifier for a purchase';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."CustomerId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."CustomerId" IS 'A unique identifier for customers';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."StaffId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."StaffId" IS 'A unique identifier for staff members';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."InvoiceNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."InvoiceNumber" IS 'The invoice number of an order';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."TotalSalePrice"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."TotalSalePrice" IS 'The total sale price of an order';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."SaleDate"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."SaleDate" IS 'The date an order was made';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."UserAuthorizationId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."SysStartTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."SysEndTime"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."RowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."SalesSalesOrderVehicleHistoryId"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."SalesSalesOrderVehicleHistoryId" IS 'A unique identifier for audit entries in SalesSalesOrderVehicleHistory';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."Note"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."IsDeleted"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."IsDeleted" IS 'Flag used to check if an entry has been deleted';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."TransactionNumber"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."FireAuditTrigger"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."AuditDateTimeStamp"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."AuditDateTimeStamp" IS 'A timestamp to record audit transactions';


--
-- Name: COLUMN "SalesSalesOrderVehicleHistory"."DBAction"; Type: COMMENT; Schema: Audit; Owner: postgres
--

COMMENT ON COLUMN "Audit"."SalesSalesOrderVehicleHistory"."DBAction" IS 'Represents the type of action that took place in the database';


--
-- Name: HumanResources_Staff_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."HumanResources_Staff_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."HumanResources_Staff_Id" OWNER TO postgres;

--
-- Name: Staff; Type: TABLE; Schema: HumanResources; Owner: postgres
--

CREATE TABLE "HumanResources"."Staff" (
    "StaffId" integer DEFAULT nextval('"SequenceIdInsert"."HumanResources_Staff_Id"'::regclass) NOT NULL,
    "ManagerId" integer,
    "StaffName" character varying(60) NOT NULL,
    "Department" character varying(15),
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "CK_HumanResources_Staff_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_HumanResources_Staff_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "HumanResources"."Staff" OWNER TO postgres;

--
-- Name: TABLE "Staff"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON TABLE "HumanResources"."Staff" IS 'A staff member of the business who sells vehicles to customers';


--
-- Name: COLUMN "Staff"."StaffId"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."StaffId" IS 'A unique identifier for staff members';


--
-- Name: COLUMN "Staff"."ManagerId"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."ManagerId" IS 'The ID of a staff member that supervises an employee';


--
-- Name: COLUMN "Staff"."StaffName"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."StaffName" IS 'The full name of a staff member';


--
-- Name: COLUMN "Staff"."Department"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."Department" IS 'The department name a staff member works in';


--
-- Name: COLUMN "Staff"."UserAuthorizationId"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "Staff"."SysStartTime"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "Staff"."SysEndTime"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "Staff"."RowLevelHashKey"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "Staff"."TransactionNumber"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "Staff"."Note"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "Staff"."PriorRowLevelHashKey"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "Staff"."FireAuditTrigger"; Type: COMMENT; Schema: HumanResources; Owner: postgres
--

COMMENT ON COLUMN "HumanResources"."Staff"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkyHumanResourcesStaff; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkyHumanResourcesStaff" AS
 SELECT "CurrentTable"."StaffId"
   FROM "HumanResources"."Staff" "CurrentTable"
UNION
 SELECT "AuditHistory"."StaffId"
   FROM "Audit"."HumanResourcesStaffHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkyHumanResourcesStaff" OWNER TO postgres;

--
-- Name: Locale_Country_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Locale_Country_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Locale_Country_Id" OWNER TO postgres;

--
-- Name: Country; Type: TABLE; Schema: Locale; Owner: postgres
--

CREATE TABLE "Locale"."Country" (
    "CountryId" integer DEFAULT nextval('"SequenceIdInsert"."Locale_Country_Id"'::regclass) NOT NULL,
    "CountryISO3" character(3) NOT NULL,
    "CountryName" character varying(50) NOT NULL,
    "CountryISO2" character varying(2) NOT NULL,
    "SalesRegion" character varying(20) NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "CK_Locale_Country_CountryISO2" CHECK ((("CountryISO2")::text ~ similar_escape('[A-Z][A-Z]'::text, NULL::text))),
    CONSTRAINT "CK_Locale_Country_CountryISO3" CHECK (("CountryISO3" ~ similar_escape('[A-Z][A-Z][A-Z]'::text, NULL::text))),
    CONSTRAINT "CK_Locale_Country_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Locale_Country_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Locale_Country_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "Locale"."Country" OWNER TO postgres;

--
-- Name: TABLE "Country"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON TABLE "Locale"."Country" IS 'A country or territory in the world';


--
-- Name: COLUMN "Country"."CountryId"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "Country"."CountryISO3"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."CountryISO3" IS 'The ISO3 format of a country';


--
-- Name: COLUMN "Country"."CountryName"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."CountryName" IS 'The name of the country';


--
-- Name: COLUMN "Country"."CountryISO2"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."CountryISO2" IS 'The ISO2 format of a country';


--
-- Name: COLUMN "Country"."SalesRegion"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."SalesRegion" IS 'The name of the sales region a coutry belongs to';


--
-- Name: COLUMN "Country"."UserAuthorizationId"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "Country"."SysStartTime"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "Country"."SysEndTime"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "Country"."RowLevelHashKey"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "Country"."TransactionNumber"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "Country"."Note"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "Country"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "Country"."FireAuditTrigger"; Type: COMMENT; Schema: Locale; Owner: postgres
--

COMMENT ON COLUMN "Locale"."Country"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkyLocaleCountry; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkyLocaleCountry" AS
 SELECT "CurrentTable"."CountryId"
   FROM "Locale"."Country" "CurrentTable"
UNION
 SELECT "AuditHistory"."CountryId"
   FROM "Audit"."LocaleCountryHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkyLocaleCountry" OWNER TO postgres;

--
-- Name: Production_ManufacturerModel_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Production_ManufacturerModel_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Production_ManufacturerModel_Id" OWNER TO postgres;

--
-- Name: ManufacturerModel; Type: TABLE; Schema: Production; Owner: postgres
--

CREATE TABLE "Production"."ManufacturerModel" (
    "ManufacturerModelId" integer DEFAULT nextval('"SequenceIdInsert"."Production_ManufacturerModel_Id"'::regclass) NOT NULL,
    "ManufacturerModelName" character varying(35) NOT NULL,
    "ManufacturerModelVariant" character varying(35),
    "ManufacturerVehicleMakeId" integer NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "CK_Production_ManufacturerModel_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Production_ManufacturerModel_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Production_ManufacturerModel_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "Production"."ManufacturerModel" OWNER TO postgres;

--
-- Name: TABLE "ManufacturerModel"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON TABLE "Production"."ManufacturerModel" IS 'The model of a particular vehicle created by the manufacturer';


--
-- Name: COLUMN "ManufacturerModel"."ManufacturerModelId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."ManufacturerModelId" IS 'A unique identifier for vehicle models';


--
-- Name: COLUMN "ManufacturerModel"."ManufacturerModelName"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."ManufacturerModelName" IS 'The name of a vehicle model';


--
-- Name: COLUMN "ManufacturerModel"."ManufacturerModelVariant"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."ManufacturerModelVariant" IS 'The name of a vehicle model variant if applicable';


--
-- Name: COLUMN "ManufacturerModel"."ManufacturerVehicleMakeId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."ManufacturerVehicleMakeId" IS 'A unique identifier for vehicle makes';


--
-- Name: COLUMN "ManufacturerModel"."UserAuthorizationId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ManufacturerModel"."SysStartTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ManufacturerModel"."SysEndTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ManufacturerModel"."RowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ManufacturerModel"."TransactionNumber"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ManufacturerModel"."Note"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ManufacturerModel"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ManufacturerModel"."FireAuditTrigger"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerModel"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkyProductionManufacturerModel; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkyProductionManufacturerModel" AS
 SELECT "CurrentTable"."ManufacturerModelId"
   FROM "Production"."ManufacturerModel" "CurrentTable"
UNION
 SELECT "AuditHistory"."ManufacturerModelId"
   FROM "Audit"."ProductionManufacturerModelHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkyProductionManufacturerModel" OWNER TO postgres;

--
-- Name: Production_ManufacturerVehicleMake_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Production_ManufacturerVehicleMake_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Production_ManufacturerVehicleMake_Id" OWNER TO postgres;

--
-- Name: ManufacturerVehicleMake; Type: TABLE; Schema: Production; Owner: postgres
--

CREATE TABLE "Production"."ManufacturerVehicleMake" (
    "ManufacturerVehicleMakeId" integer DEFAULT nextval('"SequenceIdInsert"."Production_ManufacturerVehicleMake_Id"'::regclass) NOT NULL,
    "ManufacturerVehicleMakeName" character varying(30) NOT NULL,
    "CountryId" integer NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    "MarketingType" character varying(25),
    CONSTRAINT "CK_Production_ManufacturerVehicleMake_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Production_ManufacturerVehicleMake_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Production_ManufacturerVehicleMakel_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar)))
);


ALTER TABLE "Production"."ManufacturerVehicleMake" OWNER TO postgres;

--
-- Name: TABLE "ManufacturerVehicleMake"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON TABLE "Production"."ManufacturerVehicleMake" IS 'The company responsible for the production of a vehicle';


--
-- Name: COLUMN "ManufacturerVehicleMake"."ManufacturerVehicleMakeId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."ManufacturerVehicleMakeId" IS 'A unique identifier for vehicle makes';


--
-- Name: COLUMN "ManufacturerVehicleMake"."ManufacturerVehicleMakeName"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."ManufacturerVehicleMakeName" IS 'The name of a vehicle make';


--
-- Name: COLUMN "ManufacturerVehicleMake"."CountryId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "ManufacturerVehicleMake"."UserAuthorizationId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ManufacturerVehicleMake"."SysStartTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ManufacturerVehicleMake"."SysEndTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ManufacturerVehicleMake"."RowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ManufacturerVehicleMake"."TransactionNumber"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ManufacturerVehicleMake"."Note"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ManufacturerVehicleMake"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ManufacturerVehicleMake"."FireAuditTrigger"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "ManufacturerVehicleMake"."MarketingType"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleMake"."MarketingType" IS 'The marketing type of a vehicle make';


--
-- Name: vwFindUniqueTablePkyProductionManufacturerVehicleMake; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkyProductionManufacturerVehicleMake" AS
 SELECT "CurrentTable"."ManufacturerVehicleMakeId"
   FROM "Production"."ManufacturerVehicleMake" "CurrentTable"
UNION
 SELECT "AuditHistory"."ManufacturerVehicleMakeId"
   FROM "Audit"."ProductionManufacturerVehicleMakeHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkyProductionManufacturerVehicleMake" OWNER TO postgres;

--
-- Name: Production_ManufacturerVehicleStock_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Production_ManufacturerVehicleStock_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Production_ManufacturerVehicleStock_Id" OWNER TO postgres;

--
-- Name: ManufacturerVehicleStock; Type: TABLE; Schema: Production; Owner: postgres
--

CREATE TABLE "Production"."ManufacturerVehicleStock" (
    "ManufacturerVehicleStockId" integer DEFAULT nextval('"SequenceIdInsert"."Production_ManufacturerVehicleStock_Id"'::regclass) NOT NULL,
    "StockCode" character varying(50) NOT NULL,
    "Cost" numeric(18,2) NOT NULL,
    "RepairsCharge" numeric(18,2) DEFAULT 0 NOT NULL,
    "PartsCharge" numeric(18,2) DEFAULT 0 NOT NULL,
    "DeliveryCharge" numeric(18,2) DEFAULT 0 NOT NULL,
    "IsPremiumRoadHandlingPackage" integer DEFAULT 0 NOT NULL,
    "VehicleColor" character varying(20) NOT NULL,
    "CustomerComment" character varying(200),
    "ModelId" integer NOT NULL,
    "PurchaseDate" date DEFAULT now() NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "CK_Production_ManfuacturerVehicleStock_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_Cost" CHECK (("Cost" >= (0)::numeric)),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_DeliveryCharge" CHECK (("DeliveryCharge" >= (0)::numeric)),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_IsPremiumRoadHandlingPac" CHECK ((("IsPremiumRoadHandlingPackage" = 0) OR ("IsPremiumRoadHandlingPackage" = 1))),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_PartsCharge" CHECK (("PartsCharge" >= (0)::numeric)),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_RepairsCharge" CHECK (("RepairsCharge" >= (0)::numeric)),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Production_ManufacturerVehicleStock_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "Production"."ManufacturerVehicleStock" OWNER TO postgres;

--
-- Name: TABLE "ManufacturerVehicleStock"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON TABLE "Production"."ManufacturerVehicleStock" IS 'A produced physical vehicle that a manufacturer has in stock';


--
-- Name: COLUMN "ManufacturerVehicleStock"."ManufacturerVehicleStockId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."ManufacturerVehicleStockId" IS 'A unique identifier for manfacturer vehicle stock';


--
-- Name: COLUMN "ManufacturerVehicleStock"."StockCode"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."StockCode" IS 'The stock code of a vehicle';


--
-- Name: COLUMN "ManufacturerVehicleStock"."Cost"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."Cost" IS 'The cost of a vehicle from the manufacturer';


--
-- Name: COLUMN "ManufacturerVehicleStock"."RepairsCharge"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."RepairsCharge" IS 'The charge for repairs on a vehicle';


--
-- Name: COLUMN "ManufacturerVehicleStock"."PartsCharge"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."PartsCharge" IS 'The charge for parts on a vehicle';


--
-- Name: COLUMN "ManufacturerVehicleStock"."DeliveryCharge"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."DeliveryCharge" IS 'The charge for delivery of a vehicle';


--
-- Name: COLUMN "ManufacturerVehicleStock"."IsPremiumRoadHandlingPackage"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."IsPremiumRoadHandlingPackage" IS 'A flag to determine if a vehicle has a premium road handling package';


--
-- Name: COLUMN "ManufacturerVehicleStock"."VehicleColor"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."VehicleColor" IS 'The color of the vehicle';


--
-- Name: COLUMN "ManufacturerVehicleStock"."CustomerComment"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."CustomerComment" IS 'A comment added by a customer';


--
-- Name: COLUMN "ManufacturerVehicleStock"."ModelId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."ModelId" IS 'A unique identifier for vehicle models';


--
-- Name: COLUMN "ManufacturerVehicleStock"."PurchaseDate"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."PurchaseDate" IS 'The date of purchase';


--
-- Name: COLUMN "ManufacturerVehicleStock"."UserAuthorizationId"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "ManufacturerVehicleStock"."SysStartTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "ManufacturerVehicleStock"."SysEndTime"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "ManufacturerVehicleStock"."RowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "ManufacturerVehicleStock"."TransactionNumber"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "ManufacturerVehicleStock"."Note"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "ManufacturerVehicleStock"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "ManufacturerVehicleStock"."FireAuditTrigger"; Type: COMMENT; Schema: Production; Owner: postgres
--

COMMENT ON COLUMN "Production"."ManufacturerVehicleStock"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkyProductionManufacturerVehicleStock; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkyProductionManufacturerVehicleStock" AS
 SELECT "CurrentTable"."ManufacturerVehicleStockId"
   FROM "Production"."ManufacturerVehicleStock" "CurrentTable"
UNION
 SELECT "AuditHistory"."ManufacturerVehicleStockId"
   FROM "Audit"."ProductionManufacturerVehicleStockHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkyProductionManufacturerVehicleStock" OWNER TO postgres;

--
-- Name: Sales_Customer_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Sales_Customer_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Sales_Customer_Id" OWNER TO postgres;

--
-- Name: Customer; Type: TABLE; Schema: Sales; Owner: postgres
--

CREATE TABLE "Sales"."Customer" (
    "CustomerId" integer DEFAULT nextval('"SequenceIdInsert"."Sales_Customer_Id"'::regclass) NOT NULL,
    "CustomerName" character varying(65) NOT NULL,
    "CustomerAddress1" character varying(60) NOT NULL,
    "CustomerAddress2" character varying(60),
    "CustomerTown" character varying(30) NOT NULL,
    "CustomerPostalCode" character varying(9),
    "CountryId" integer NOT NULL,
    "IsCustomerReseller" integer NOT NULL,
    "IsCustomerCreditRisk" integer NOT NULL,
    "SpendCapacity" character varying(15),
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "BCK_TemplateTable_ValidBit_161407054" CHECK ((("IsCustomerCreditRisk" = 0) OR ("IsCustomerCreditRisk" = 1))),
    CONSTRAINT "CK_Sales_Customer_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Sales_Customer_IsCustomerReseller" CHECK ((("IsCustomerReseller" = 0) OR ("IsCustomerReseller" = 1))),
    CONSTRAINT "CK_Sales_Customer_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Sales_Customer_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "Sales"."Customer" OWNER TO postgres;

--
-- Name: TABLE "Customer"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON TABLE "Sales"."Customer" IS 'A person who purchases a vehicle from the business';


--
-- Name: COLUMN "Customer"."CustomerId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerId" IS 'A unique identifier for customers';


--
-- Name: COLUMN "Customer"."CustomerName"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerName" IS 'The full name of a customer';


--
-- Name: COLUMN "Customer"."CustomerAddress1"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerAddress1" IS 'The street address of a customer';


--
-- Name: COLUMN "Customer"."CustomerAddress2"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerAddress2" IS 'The extended street address of a customer';


--
-- Name: COLUMN "Customer"."CustomerTown"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerTown" IS 'The town or city a customer resides in';


--
-- Name: COLUMN "Customer"."CustomerPostalCode"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CustomerPostalCode" IS 'The postal code of a customer if applicable';


--
-- Name: COLUMN "Customer"."CountryId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."CountryId" IS 'A unique identifier for countries';


--
-- Name: COLUMN "Customer"."IsCustomerReseller"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."IsCustomerReseller" IS 'Flag to determine if a customer is a reseller';


--
-- Name: COLUMN "Customer"."IsCustomerCreditRisk"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."IsCustomerCreditRisk" IS 'Flag to determine if customer is a credit risk';


--
-- Name: COLUMN "Customer"."SpendCapacity"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."SpendCapacity" IS 'The spend capacity of a customer';


--
-- Name: COLUMN "Customer"."UserAuthorizationId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "Customer"."SysStartTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "Customer"."SysEndTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "Customer"."RowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "Customer"."TransactionNumber"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "Customer"."Note"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "Customer"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "Customer"."FireAuditTrigger"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."Customer"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkySalesCustomer; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkySalesCustomer" AS
 SELECT "CurrentTable"."CustomerId"
   FROM "Sales"."Customer" "CurrentTable"
UNION
 SELECT "AuditHistory"."CustomerId"
   FROM "Audit"."SalesCustomerHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkySalesCustomer" OWNER TO postgres;

--
-- Name: Sales_SalesOrderVehicle_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Sales_SalesOrderVehicle_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Sales_SalesOrderVehicle_Id" OWNER TO postgres;

--
-- Name: SalesOrderVehicle; Type: TABLE; Schema: Sales; Owner: postgres
--

CREATE TABLE "Sales"."SalesOrderVehicle" (
    "SalesOrderVehicleId" integer DEFAULT nextval('"SequenceIdInsert"."Sales_SalesOrderVehicle_Id"'::regclass) NOT NULL,
    "CustomerId" integer NOT NULL,
    "StaffId" integer NOT NULL,
    "InvoiceNumber" character varying(8) NOT NULL,
    "TotalSalePrice" numeric(18,2) DEFAULT 0 NOT NULL,
    "SaleDate" date DEFAULT now() NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    "CategoryDescription" character varying(20) NOT NULL,
    CONSTRAINT "CK_Sales_SalesOrderVehicle_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Sales_SalesOrderVehicle_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Sales_SalesOrderVehicle_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Sales_SalesOrderVehicle_TotalSalePrice" CHECK (("TotalSalePrice" >= (0)::numeric))
);


ALTER TABLE "Sales"."SalesOrderVehicle" OWNER TO postgres;

--
-- Name: TABLE "SalesOrderVehicle"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON TABLE "Sales"."SalesOrderVehicle" IS 'An order for the purchase of a vehicle';


--
-- Name: COLUMN "SalesOrderVehicle"."SalesOrderVehicleId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."SalesOrderVehicleId" IS 'A unique identifier for a purchase';


--
-- Name: COLUMN "SalesOrderVehicle"."CustomerId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."CustomerId" IS 'A unique identifier for customers';


--
-- Name: COLUMN "SalesOrderVehicle"."StaffId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."StaffId" IS 'A unique identifier for staff members';


--
-- Name: COLUMN "SalesOrderVehicle"."InvoiceNumber"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."InvoiceNumber" IS 'The invoice number of an order';


--
-- Name: COLUMN "SalesOrderVehicle"."TotalSalePrice"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."TotalSalePrice" IS 'The total sale price of an order';


--
-- Name: COLUMN "SalesOrderVehicle"."SaleDate"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."SaleDate" IS 'The date an order was made';


--
-- Name: COLUMN "SalesOrderVehicle"."UserAuthorizationId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "SalesOrderVehicle"."SysStartTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "SalesOrderVehicle"."SysEndTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "SalesOrderVehicle"."RowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "SalesOrderVehicle"."TransactionNumber"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "SalesOrderVehicle"."Note"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "SalesOrderVehicle"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "SalesOrderVehicle"."FireAuditTrigger"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: COLUMN "SalesOrderVehicle"."CategoryDescription"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicle"."CategoryDescription" IS 'The category description a vehicle sales threshold';


--
-- Name: vwFindUniqueTablePkySalesSalesOrderVehicle; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkySalesSalesOrderVehicle" AS
 SELECT "CurrentTable"."SalesOrderVehicleId"
   FROM "Sales"."SalesOrderVehicle" "CurrentTable"
UNION
 SELECT "AuditHistory"."SalesOrderVehicleId"
   FROM "Audit"."SalesSalesOrderVehicleHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkySalesSalesOrderVehicle" OWNER TO postgres;

--
-- Name: Sales_SalesOrderVehicleDetail_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Sales_SalesOrderVehicleDetail_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Sales_SalesOrderVehicleDetail_Id" OWNER TO postgres;

--
-- Name: SalesOrderVehicleDetail; Type: TABLE; Schema: Sales; Owner: postgres
--

CREATE TABLE "Sales"."SalesOrderVehicleDetail" (
    "SalesOrderVehicleDetailId" integer DEFAULT nextval('"SequenceIdInsert"."Sales_SalesOrderVehicleDetail_Id"'::regclass) NOT NULL,
    "SalesOrderVehicleId" integer NOT NULL,
    "LineItemNumber" integer DEFAULT 1 NOT NULL,
    "SalePrice" numeric(18,2) DEFAULT 0 NOT NULL,
    "LineItemDiscount" numeric(18,2) DEFAULT 0 NOT NULL,
    "DerivedDiscountedSalePrice" numeric(18,2) NOT NULL,
    "ManufacturerVehicleStockId" integer NOT NULL,
    "UserAuthorizationId" integer DEFAULT 1 NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "RowLevelHashKey" bytea,
    "TransactionNumber" integer DEFAULT 1 NOT NULL,
    "Note" character varying(100) DEFAULT 'Row was inserted'::character varying,
    "PriorRowLevelHashKey" bytea,
    "FireAuditTrigger" character(1) DEFAULT 'N'::bpchar NOT NULL,
    CONSTRAINT "CK_Sales_SalesOrderVehicleDetail_FireAuditTrigger" CHECK ((("FireAuditTrigger" = 'Y'::bpchar) OR ("FireAuditTrigger" = 'N'::bpchar))),
    CONSTRAINT "CK_Sales_SalesOrderVehicleDetail_LineItemDiscount" CHECK (("LineItemDiscount" >= (0)::numeric)),
    CONSTRAINT "CK_Sales_SalesOrderVehicleDetail_SalePrice" CHECK (("SalePrice" >= (0)::numeric)),
    CONSTRAINT "CK_Sales_SalesOrderVehicleDetail_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_Sales_SalesOrderVehicleDetail_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "Sales"."SalesOrderVehicleDetail" OWNER TO postgres;

--
-- Name: TABLE "SalesOrderVehicleDetail"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON TABLE "Sales"."SalesOrderVehicleDetail" IS 'The details of a vehicle order';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."SalesOrderVehicleDetailId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."SalesOrderVehicleDetailId" IS 'A unique identifier for SalesOrderVehicleDetail Ids';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."SalesOrderVehicleId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."SalesOrderVehicleId" IS 'A unique identifier for a purchase';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."LineItemNumber"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."LineItemNumber" IS 'The line item number on the invoice';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."SalePrice"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."SalePrice" IS 'The sale price of a vehicle';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."LineItemDiscount"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."LineItemDiscount" IS 'The discount of the line item number';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."DerivedDiscountedSalePrice"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."DerivedDiscountedSalePrice" IS 'The derived discounted sale price of a vehicle';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."ManufacturerVehicleStockId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."ManufacturerVehicleStockId" IS 'A unique identifier for manfacturer vehicle stock';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."UserAuthorizationId"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."SysStartTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."SysEndTime"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."RowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."RowLevelHashKey" IS 'Current row hash key representing all combined columns';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."TransactionNumber"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."TransactionNumber" IS 'The transaction number in a series of database transactions';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."Note"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."Note" IS 'A note regarding the database transaction';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."PriorRowLevelHashKey"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."PriorRowLevelHashKey" IS 'The prior transaction row level hash key';


--
-- Name: COLUMN "SalesOrderVehicleDetail"."FireAuditTrigger"; Type: COMMENT; Schema: Sales; Owner: postgres
--

COMMENT ON COLUMN "Sales"."SalesOrderVehicleDetail"."FireAuditTrigger" IS 'A flag to indicate if an audit trigger should be fired';


--
-- Name: vwFindUniqueTablePkySalesSalesOrderVehicleDetail; Type: VIEW; Schema: Audit; Owner: postgres
--

CREATE VIEW "Audit"."vwFindUniqueTablePkySalesSalesOrderVehicleDetail" AS
 SELECT "CurrentTable"."SalesOrderVehicleDetailId"
   FROM "Sales"."SalesOrderVehicleDetail" "CurrentTable"
UNION
 SELECT "AuditHistory"."SalesOrderVehicleDetailId"
   FROM "Audit"."SalesSalesOrderVehicleDetailHistory" "AuditHistory";


ALTER TABLE "Audit"."vwFindUniqueTablePkySalesSalesOrderVehicleDetail" OWNER TO postgres;

--
-- Name: uvw_ChuanCustomerCountry; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_ChuanCustomerCountry" AS
 SELECT "SC"."CustomerName",
    "LC"."CountryName"
   FROM ("Sales"."Customer" "SC"
     JOIN "Locale"."Country" "LC" ON (("LC"."CountryId" = "SC"."CountryId")));


ALTER TABLE "CustomViews"."uvw_ChuanCustomerCountry" OWNER TO postgres;

--
-- Name: uvw_ChuanMakeCountry; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_ChuanMakeCountry" AS
 SELECT "LC"."CountryName" AS "Country",
    "PMVM"."ManufacturerVehicleMakeName" AS "Make"
   FROM ("Production"."ManufacturerVehicleMake" "PMVM"
     JOIN "Locale"."Country" "LC" ON (("PMVM"."CountryId" = "LC"."CountryId")));


ALTER TABLE "CustomViews"."uvw_ChuanMakeCountry" OWNER TO postgres;

--
-- Name: uvw_ChuanModelMake; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_ChuanModelMake" AS
 SELECT "PMM"."ManufacturerModelName" AS "Model",
    "PMVM"."ManufacturerVehicleMakeName" AS "Make"
   FROM ("Production"."ManufacturerModel" "PMM"
     JOIN "Production"."ManufacturerVehicleMake" "PMVM" ON (("PMM"."ManufacturerVehicleMakeId" = "PMVM"."ManufacturerVehicleMakeId")));


ALTER TABLE "CustomViews"."uvw_ChuanModelMake" OWNER TO postgres;

--
-- Name: uvw_ChuanStaffDiscountGiven; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_ChuanStaffDiscountGiven" AS
 SELECT "HRS"."StaffName",
    sum("SSOVD"."LineItemDiscount") AS "DiscountGiven"
   FROM (("HumanResources"."Staff" "HRS"
     JOIN "Sales"."SalesOrderVehicle" "SSOV" ON (("HRS"."StaffId" = "SSOV"."StaffId")))
     JOIN "Sales"."SalesOrderVehicleDetail" "SSOVD" ON (("SSOV"."SalesOrderVehicleId" = "SSOVD"."SalesOrderVehicleId")))
  GROUP BY "HRS"."StaffName";


ALTER TABLE "CustomViews"."uvw_ChuanStaffDiscountGiven" OWNER TO postgres;

--
-- Name: uvw_MehrshadYearlyCustomerSales; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_MehrshadYearlyCustomerSales" AS
 SELECT "SalesOrderVehicle"."SaleDate",
    "Customer"."CustomerName",
    "ManufacturerVehicleMake"."ManufacturerVehicleMakeName",
    "ManufacturerModel"."ManufacturerModelName",
    "SalesOrderVehicleDetail"."SalePrice"
   FROM (((("Sales"."SalesOrderVehicleDetail"
     JOIN "Sales"."SalesOrderVehicle" ON (("SalesOrderVehicleDetail"."SalesOrderVehicleId" = "SalesOrderVehicle"."SalesOrderVehicleId")))
     JOIN "Sales"."Customer" ON (("SalesOrderVehicle"."CustomerId" = "Customer"."CustomerId")))
     CROSS JOIN "Production"."ManufacturerModel")
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId")));


ALTER TABLE "CustomViews"."uvw_MehrshadYearlyCustomerSales" OWNER TO postgres;

--
-- Name: uvw_MehrshadYearlySalesProfits; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_MehrshadYearlySalesProfits" AS
 SELECT date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") AS "SalesYear",
    "ManufacturerVehicleMake"."ManufacturerVehicleMakeName" AS "MakeName",
    "ManufacturerModel"."ManufacturerModelName" AS "ModelName",
    "Customer"."CustomerName",
    "ManufacturerVehicleStock"."Cost",
    "ManufacturerVehicleStock"."RepairsCharge",
    "ManufacturerVehicleStock"."PartsCharge" AS "PartsCost",
    "ManufacturerVehicleStock"."DeliveryCharge" AS "TransportInCost",
    "SalesOrderVehicleDetail"."SalePrice",
    "SalesOrderVehicle"."SaleDate",
    (((("SalesOrderVehicleDetail"."SalePrice" - "ManufacturerVehicleStock"."Cost") - "ManufacturerVehicleStock"."RepairsCharge") - "ManufacturerVehicleStock"."PartsCharge") - "ManufacturerVehicleStock"."DeliveryCharge") AS "Profit"
   FROM ((((("Sales"."Customer"
     JOIN "Sales"."SalesOrderVehicle" ON (("Customer"."CustomerId" = "SalesOrderVehicle"."CustomerId")))
     JOIN "Sales"."SalesOrderVehicleDetail" ON (("SalesOrderVehicle"."SalesOrderVehicleId" = "SalesOrderVehicleDetail"."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
     JOIN "Production"."ManufacturerModel" ON (("ManufacturerModel"."ManufacturerModelId" = "ManufacturerVehicleStock"."ModelId")))
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId")));


ALTER TABLE "CustomViews"."uvw_MehrshadYearlySalesProfits" OWNER TO postgres;

--
-- Name: uvw_MershadVehicleCost; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_MershadVehicleCost" AS
 SELECT "ManufacturerVehicleMake"."ManufacturerVehicleMakeName",
    "ManufacturerModel"."ManufacturerModelName",
    "ManufacturerVehicleStock"."Cost"
   FROM (((("Sales"."SalesOrderVehicleDetail"
     JOIN "Sales"."SalesOrderVehicle" ON (("SalesOrderVehicleDetail"."SalesOrderVehicleId" = "SalesOrderVehicle"."SalesOrderVehicleId")))
     JOIN "Sales"."Customer" ON (("SalesOrderVehicle"."CustomerId" = "Customer"."CustomerId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
     JOIN ("Production"."ManufacturerModel"
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId"))) ON (("ManufacturerVehicleStock"."ModelId" = "ManufacturerModel"."ManufacturerModelId")));


ALTER TABLE "CustomViews"."uvw_MershadVehicleCost" OWNER TO postgres;

--
-- Name: uvw_RalphMakeModelPartsCost; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_RalphMakeModelPartsCost" AS
 SELECT mvm."ManufacturerVehicleMakeName" AS "Make",
    mm."ManufacturerModelName" AS "Model",
    mvs."PartsCharge" AS "Parts Cost"
   FROM (("Production"."ManufacturerVehicleStock" mvs
     JOIN "Production"."ManufacturerModel" mm ON ((mm."ManufacturerModelId" = mvs."ModelId")))
     JOIN "Production"."ManufacturerVehicleMake" mvm ON ((mm."ManufacturerVehicleMakeId" = mvm."ManufacturerVehicleMakeId")));


ALTER TABLE "CustomViews"."uvw_RalphMakeModelPartsCost" OWNER TO postgres;

--
-- Name: uvw_Ralph_EmployeeManager; Type: VIEW; Schema: CustomViews; Owner: postgres
--

CREATE VIEW "CustomViews"."uvw_Ralph_EmployeeManager" AS
 SELECT emp."StaffName" AS "Employee Name",
    emp."Department" AS "Employee Department",
    mgr."StaffName" AS "Manager Name",
    mgr."Department" AS "Manager Department"
   FROM ("HumanResources"."Staff" emp
     JOIN "HumanResources"."Staff" mgr ON ((emp."ManagerId" = mgr."StaffId")));


ALTER TABLE "CustomViews"."uvw_Ralph_EmployeeManager" OWNER TO postgres;

--
-- Name: DbSecurity_UserAuthorization_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."DbSecurity_UserAuthorization_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."DbSecurity_UserAuthorization_Id" OWNER TO postgres;

--
-- Name: UserAuthorization; Type: TABLE; Schema: DbSecurity; Owner: postgres
--

CREATE TABLE "DbSecurity"."UserAuthorization" (
    "UserAuthorizationId" integer DEFAULT nextval('"SequenceIdInsert"."DbSecurity_UserAuthorization_Id"'::regclass) NOT NULL,
    "ClassTime" character(5) DEFAULT '10:45'::bpchar,
    "IndividualProject" character varying(60) DEFAULT 'CSCI381 Final Project'::character varying,
    "GroupMemberLastName" character varying(35) NOT NULL,
    "GroupMemberFirstName" character varying(25) NOT NULL,
    "SysStartTime" timestamp without time zone DEFAULT now(),
    "SysEndTime" timestamp without time zone DEFAULT '10000-01-01 00:00:00'::timestamp without time zone,
    "GroupName" character varying(20) DEFAULT 'Group 3'::character varying NOT NULL,
    CONSTRAINT "CK_DbSecurity_UserAuthorization_ClassTime" CHECK ((("ClassTime" ~ similar_escape('[0-1][0-9]:[0-5][0-9]'::text, NULL::text)) OR ("ClassTime" ~ similar_escape('[0-2][0-4]:[0-5][0-9]'::text, NULL::text)))),
    CONSTRAINT "CK_DbSecurity_UserAuthorization_SysEndTime" CHECK (("SysEndTime" >= "SysStartTime")),
    CONSTRAINT "CK_DbSecurity_UserAuthorization_SysStartTime" CHECK (("SysEndTime" >= "SysStartTime"))
);


ALTER TABLE "DbSecurity"."UserAuthorization" OWNER TO postgres;

--
-- Name: TABLE "UserAuthorization"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON TABLE "DbSecurity"."UserAuthorization" IS 'The authorization of database actions by a user';


--
-- Name: COLUMN "UserAuthorization"."UserAuthorizationId"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."UserAuthorizationId" IS 'A unique identifier for UserAuthorizationIds';


--
-- Name: COLUMN "UserAuthorization"."ClassTime"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."ClassTime" IS 'The class time for CSCI381 Data Modeling';


--
-- Name: COLUMN "UserAuthorization"."IndividualProject"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."IndividualProject" IS 'The name of the individual project';


--
-- Name: COLUMN "UserAuthorization"."GroupMemberLastName"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."GroupMemberLastName" IS 'The group members last name';


--
-- Name: COLUMN "UserAuthorization"."GroupMemberFirstName"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."GroupMemberFirstName" IS 'The group members first name';


--
-- Name: COLUMN "UserAuthorization"."SysStartTime"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."SysStartTime" IS 'The start time for a system transaction';


--
-- Name: COLUMN "UserAuthorization"."SysEndTime"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."SysEndTime" IS 'The end time for a system transaction';


--
-- Name: COLUMN "UserAuthorization"."GroupName"; Type: COMMENT; Schema: DbSecurity; Owner: postgres
--

COMMENT ON COLUMN "DbSecurity"."UserAuthorization"."GroupName" IS 'The name of the group';


--
-- Name: uvw_ChuanStaffSales; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_ChuanStaffSales" AS
 SELECT "HRS"."StaffName",
    sum("SSOV"."TotalSalePrice") AS "TotalSales"
   FROM ("HumanResources"."Staff" "HRS"
     JOIN "Sales"."SalesOrderVehicle" "SSOV" ON (("HRS"."StaffId" = "SSOV"."StaffId")))
  GROUP BY "HRS"."StaffName";


ALTER TABLE "Sales"."uvw_ChuanStaffSales" OWNER TO postgres;

--
-- Name: uvw_PivotTable; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_PivotTable" AS
 SELECT "ManufacturerVehicleStock"."VehicleColor",
    (sum(
        CASE
            WHEN (date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") = (2015)::double precision) THEN "SalesOrderVehicle"."TotalSalePrice"
            ELSE (0)::numeric
        END))::integer AS "CY2015",
    (sum(
        CASE
            WHEN (date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") = (2016)::double precision) THEN "SalesOrderVehicle"."TotalSalePrice"
            ELSE (0)::numeric
        END))::integer AS "CY2016",
    (sum(
        CASE
            WHEN (date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") = (2017)::double precision) THEN "SalesOrderVehicle"."TotalSalePrice"
            ELSE (0)::numeric
        END))::integer AS "CY2017",
    (sum(
        CASE
            WHEN (date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") = (2018)::double precision) THEN "SalesOrderVehicle"."TotalSalePrice"
            ELSE (0)::numeric
        END))::integer AS "CY2018"
   FROM (("Sales"."SalesOrderVehicle"
     JOIN "Sales"."SalesOrderVehicleDetail" ON (("SalesOrderVehicle"."SalesOrderVehicleId" = "SalesOrderVehicleDetail"."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
  GROUP BY "ManufacturerVehicleStock"."VehicleColor";


ALTER TABLE "Sales"."uvw_PivotTable" OWNER TO postgres;

--
-- Name: uvw_Sales2018; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_Sales2018" AS
 SELECT date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") AS "SalesYear",
    "ManufacturerVehicleMake"."ManufacturerVehicleMakeName" AS "MakeName",
    "ManufacturerModel"."ManufacturerModelName" AS "ModelName",
    "Customer"."CustomerName",
    "Country"."CountryName",
    "ManufacturerVehicleStock"."Cost",
    "ManufacturerVehicleStock"."RepairsCharge" AS repaircost,
    "ManufacturerVehicleStock"."PartsCharge" AS "PartsCost",
    "ManufacturerVehicleStock"."DeliveryCharge" AS "TransportInCost",
    ("SalesOrderVehicleDetail"."SalePrice")::integer AS "SalePrice",
    "SalesOrderVehicle"."SaleDate"
   FROM (((((("Sales"."Customer"
     JOIN "Sales"."SalesOrderVehicle" ON (("Customer"."CustomerId" = "SalesOrderVehicle"."CustomerId")))
     JOIN "Locale"."Country" ON (("Customer"."CountryId" = "Country"."CountryId")))
     JOIN "Sales"."SalesOrderVehicleDetail" ON (("SalesOrderVehicle"."SalesOrderVehicleId" = "SalesOrderVehicleDetail"."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
     JOIN "Production"."ManufacturerModel" ON (("ManufacturerModel"."ManufacturerModelId" = "ManufacturerVehicleStock"."ModelId")))
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId")))
  WHERE (date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") = (2018)::double precision);


ALTER TABLE "Sales"."uvw_Sales2018" OWNER TO postgres;

--
-- Name: uvw_SalesByCountry; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_SalesByCountry" AS
 SELECT "Country"."CountryName",
    "ManufacturerVehicleMake"."ManufacturerVehicleMakeName" AS "MakeName",
    "ManufacturerModel"."ManufacturerModelName" AS "ModelName",
    "ManufacturerVehicleStock"."Cost",
    "ManufacturerVehicleStock"."RepairsCharge" AS "RepairsCost",
    "ManufacturerVehicleStock"."PartsCharge" AS "PartsCost",
    "ManufacturerVehicleStock"."DeliveryCharge" AS "TransportInCost",
    "ManufacturerVehicleStock"."VehicleColor" AS "Color",
    ("SalesOrderVehicleDetail"."SalePrice")::integer AS saleprice,
    ("SalesOrderVehicleDetail"."LineItemDiscount")::integer AS lineitemdiscount,
    "SalesOrderVehicle"."InvoiceNumber",
    "SalesOrderVehicle"."SaleDate" AS saledate,
    "Customer"."CustomerName",
    "SalesOrderVehicleDetail"."SalesOrderVehicleDetailId" AS "SalesDetailsID"
   FROM (((((("Sales"."SalesOrderVehicle"
     JOIN "Sales"."Customer" ON (("SalesOrderVehicle"."CustomerId" = "Customer"."CustomerId")))
     JOIN "Locale"."Country" ON (("Customer"."CountryId" = "Country"."CountryId")))
     JOIN "Sales"."SalesOrderVehicleDetail" ON (("SalesOrderVehicle"."SalesOrderVehicleId" = "SalesOrderVehicleDetail"."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
     JOIN "Production"."ManufacturerModel" ON (("ManufacturerVehicleStock"."ModelId" = "ManufacturerModel"."ManufacturerModelId")))
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId")));


ALTER TABLE "Sales"."uvw_SalesByCountry" OWNER TO postgres;

--
-- Name: uvw_SalesText; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_SalesText" AS
 SELECT co."CountryName",
    mvm."ManufacturerVehicleMakeName" AS "MakeName",
    mvs."Cost",
    sv."TotalSalePrice" AS "SalePrice"
   FROM (((((("Sales"."SalesOrderVehicle" sv
     JOIN "Sales"."SalesOrderVehicleDetail" svd ON ((svd."SalesOrderVehicleId" = sv."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" mvs ON ((svd."ManufacturerVehicleStockId" = mvs."ManufacturerVehicleStockId")))
     JOIN "Production"."ManufacturerModel" mm ON ((mvs."ModelId" = mm."ManufacturerModelId")))
     JOIN "Production"."ManufacturerVehicleMake" mvm ON ((mvm."ManufacturerVehicleMakeId" = mm."ManufacturerVehicleMakeId")))
     JOIN "Sales"."Customer" c ON ((sv."CustomerId" = c."CustomerId")))
     JOIN "Locale"."Country" co ON ((c."CountryId" = co."CountryId")));


ALTER TABLE "Sales"."uvw_SalesText" OWNER TO postgres;

--
-- Name: uvw_StockPrices; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_StockPrices" AS
 SELECT mvsmm."ManufacturerVehicleMakeName" AS "MakeName",
    mm."ManufacturerModelName" AS "ModelName",
    mvs."Cost" AS "RetailCost"
   FROM (("Production"."ManufacturerVehicleStock" mvs
     JOIN "Production"."ManufacturerModel" mm ON ((mvs."ModelId" = mm."ManufacturerModelId")))
     JOIN "Production"."ManufacturerVehicleMake" mvsmm ON ((mm."ManufacturerVehicleMakeId" = mvsmm."ManufacturerVehicleMakeId")));


ALTER TABLE "Sales"."uvw_StockPrices" OWNER TO postgres;

--
-- Name: uvw_YearlySales; Type: VIEW; Schema: Sales; Owner: postgres
--

CREATE VIEW "Sales"."uvw_YearlySales" AS
 SELECT date_part('YEAR'::text, "SalesOrderVehicle"."SaleDate") AS "SalesYear",
    "ManufacturerVehicleMake"."ManufacturerVehicleMakeName" AS "MakeName",
    "ManufacturerModel"."ManufacturerModelName" AS "ModelName",
    "Customer"."CustomerName",
    "Country"."CountryName",
    "ManufacturerVehicleStock"."Cost",
    "ManufacturerVehicleStock"."RepairsCharge" AS "RepairsCost",
    "ManufacturerVehicleStock"."PartsCharge" AS "PartsCost",
    "ManufacturerVehicleStock"."DeliveryCharge" AS "TransportInCost",
    ("SalesOrderVehicleDetail"."SalePrice")::integer AS "SalePrice",
    "SalesOrderVehicle"."SaleDate"
   FROM (((((("Sales"."Customer"
     JOIN "Sales"."SalesOrderVehicle" ON (("Customer"."CustomerId" = "SalesOrderVehicle"."CustomerId")))
     JOIN "Locale"."Country" ON (("Customer"."CountryId" = "Country"."CountryId")))
     JOIN "Sales"."SalesOrderVehicleDetail" ON (("SalesOrderVehicle"."SalesOrderVehicleId" = "SalesOrderVehicleDetail"."SalesOrderVehicleId")))
     JOIN "Production"."ManufacturerVehicleStock" ON (("SalesOrderVehicleDetail"."ManufacturerVehicleStockId" = "ManufacturerVehicleStock"."ManufacturerVehicleStockId")))
     JOIN "Production"."ManufacturerModel" ON (("ManufacturerModel"."ManufacturerModelId" = "ManufacturerVehicleStock"."ModelId")))
     JOIN "Production"."ManufacturerVehicleMake" ON (("ManufacturerModel"."ManufacturerVehicleMakeId" = "ManufacturerVehicleMake"."ManufacturerVehicleMakeId")));


ALTER TABLE "Sales"."uvw_YearlySales" OWNER TO postgres;

--
-- Name: Audit_SalesSalesCategoryThresholdHistory_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Audit_SalesSalesCategoryThresholdHistory_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Audit_SalesSalesCategoryThresholdHistory_Id" OWNER TO postgres;

--
-- Name: Sales_SalesCategoryThreshold_Id; Type: SEQUENCE; Schema: SequenceIdInsert; Owner: postgres
--

CREATE SEQUENCE "SequenceIdInsert"."Sales_SalesCategoryThreshold_Id"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "SequenceIdInsert"."Sales_SalesCategoryThreshold_Id" OWNER TO postgres;

--
-- Data for Name: HumanResourcesStaffHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."HumanResourcesStaffHistory" ("StaffId", "StaffName", "Department", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ManagerId", "Note", "IsDeleted", "TransactionNumber", "StaffHistoryId", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."HumanResourcesStaffHistory" ("StaffId", "StaffName", "Department", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ManagerId", "Note", "IsDeleted", "TransactionNumber", "StaffHistoryId", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3715.dat';

--
-- Data for Name: LocaleCountryHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."LocaleCountryHistory" ("CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "LocaleCountryHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."LocaleCountryHistory" ("CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "LocaleCountryHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3716.dat';

--
-- Data for Name: ProductionManufacturerModelHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."ProductionManufacturerModelHistory" ("ManufacturerModelId", "ManufacturerModelName", "ManufacturerModelVariant", "ManufacturerVehicleMakeId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerModelHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."ProductionManufacturerModelHistory" ("ManufacturerModelId", "ManufacturerModelName", "ManufacturerModelVariant", "ManufacturerVehicleMakeId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerModelHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3720.dat';

--
-- Data for Name: ProductionManufacturerVehicleMakeHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."ProductionManufacturerVehicleMakeHistory" ("ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerVehicleMakeHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "MarketingType") FROM stdin;
\.
COPY "Audit"."ProductionManufacturerVehicleMakeHistory" ("ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerVehicleMakeHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "MarketingType") FROM '$$PATH$$/3721.dat';

--
-- Data for Name: ProductionManufacturerVehicleStockHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."ProductionManufacturerVehicleStockHistory" ("ManufacturerVehicleStockId", "StockCode", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "ModelId", "PurchaseDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerVehicleStockHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."ProductionManufacturerVehicleStockHistory" ("ManufacturerVehicleStockId", "StockCode", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "ModelId", "PurchaseDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "ProductionManufacturerVehicleStockHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3722.dat';

--
-- Data for Name: SalesCustomerHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."SalesCustomerHistory" ("CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesCustomerHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."SalesCustomerHistory" ("CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesCustomerHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3723.dat';

--
-- Data for Name: SalesSalesOrderVehicleDetailHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."SalesSalesOrderVehicleDetailHistory" ("SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "SalePrice", "LineItemDiscount", "ManufacturerVehicleStockId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesSalesOrderVehicleDetailHistoryId", "Note", "IsDeleted", "TransactionNumber", "DerivedDiscountedSalePrice", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM stdin;
\.
COPY "Audit"."SalesSalesOrderVehicleDetailHistory" ("SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "SalePrice", "LineItemDiscount", "ManufacturerVehicleStockId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesSalesOrderVehicleDetailHistoryId", "Note", "IsDeleted", "TransactionNumber", "DerivedDiscountedSalePrice", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction") FROM '$$PATH$$/3726.dat';

--
-- Data for Name: SalesSalesOrderVehicleHistory; Type: TABLE DATA; Schema: Audit; Owner: postgres
--

COPY "Audit"."SalesSalesOrderVehicleHistory" ("SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesSalesOrderVehicleHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "CategoryDescription") FROM stdin;
\.
COPY "Audit"."SalesSalesOrderVehicleHistory" ("SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "SalesSalesOrderVehicleHistoryId", "Note", "IsDeleted", "TransactionNumber", "PriorRowLevelHashKey", "FireAuditTrigger", "AuditDateTimeStamp", "DBAction", "CategoryDescription") FROM '$$PATH$$/3727.dat';

--
-- Data for Name: UserAuthorization; Type: TABLE DATA; Schema: DbSecurity; Owner: postgres
--

COPY "DbSecurity"."UserAuthorization" ("UserAuthorizationId", "ClassTime", "IndividualProject", "GroupMemberLastName", "GroupMemberFirstName", "SysStartTime", "SysEndTime", "GroupName") FROM stdin;
\.
COPY "DbSecurity"."UserAuthorization" ("UserAuthorizationId", "ClassTime", "IndividualProject", "GroupMemberLastName", "GroupMemberFirstName", "SysStartTime", "SysEndTime", "GroupName") FROM '$$PATH$$/3729.dat';

--
-- Data for Name: Staff; Type: TABLE DATA; Schema: HumanResources; Owner: postgres
--

COPY "HumanResources"."Staff" ("StaffId", "ManagerId", "StaffName", "Department", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "HumanResources"."Staff" ("StaffId", "ManagerId", "StaffName", "Department", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3728.dat';

--
-- Data for Name: Country; Type: TABLE DATA; Schema: Locale; Owner: postgres
--

COPY "Locale"."Country" ("CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "Locale"."Country" ("CountryId", "CountryISO3", "CountryName", "CountryISO2", "SalesRegion", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3713.dat';

--
-- Data for Name: ManufacturerModel; Type: TABLE DATA; Schema: Production; Owner: postgres
--

COPY "Production"."ManufacturerModel" ("ManufacturerModelId", "ManufacturerModelName", "ManufacturerModelVariant", "ManufacturerVehicleMakeId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "Production"."ManufacturerModel" ("ManufacturerModelId", "ManufacturerModelName", "ManufacturerModelVariant", "ManufacturerVehicleMakeId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3717.dat';

--
-- Data for Name: ManufacturerVehicleMake; Type: TABLE DATA; Schema: Production; Owner: postgres
--

COPY "Production"."ManufacturerVehicleMake" ("ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger", "MarketingType") FROM stdin;
\.
COPY "Production"."ManufacturerVehicleMake" ("ManufacturerVehicleMakeId", "ManufacturerVehicleMakeName", "CountryId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger", "MarketingType") FROM '$$PATH$$/3718.dat';

--
-- Data for Name: ManufacturerVehicleStock; Type: TABLE DATA; Schema: Production; Owner: postgres
--

COPY "Production"."ManufacturerVehicleStock" ("ManufacturerVehicleStockId", "StockCode", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "ModelId", "PurchaseDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "Production"."ManufacturerVehicleStock" ("ManufacturerVehicleStockId", "StockCode", "Cost", "RepairsCharge", "PartsCharge", "DeliveryCharge", "IsPremiumRoadHandlingPackage", "VehicleColor", "CustomerComment", "ModelId", "PurchaseDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3719.dat';

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: Sales; Owner: postgres
--

COPY "Sales"."Customer" ("CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "Sales"."Customer" ("CustomerId", "CustomerName", "CustomerAddress1", "CustomerAddress2", "CustomerTown", "CustomerPostalCode", "CountryId", "IsCustomerReseller", "IsCustomerCreditRisk", "SpendCapacity", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3714.dat';

--
-- Data for Name: SalesOrderVehicle; Type: TABLE DATA; Schema: Sales; Owner: postgres
--

COPY "Sales"."SalesOrderVehicle" ("SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger", "CategoryDescription") FROM stdin;
\.
COPY "Sales"."SalesOrderVehicle" ("SalesOrderVehicleId", "CustomerId", "StaffId", "InvoiceNumber", "TotalSalePrice", "SaleDate", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger", "CategoryDescription") FROM '$$PATH$$/3724.dat';

--
-- Data for Name: SalesOrderVehicleDetail; Type: TABLE DATA; Schema: Sales; Owner: postgres
--

COPY "Sales"."SalesOrderVehicleDetail" ("SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "SalePrice", "LineItemDiscount", "DerivedDiscountedSalePrice", "ManufacturerVehicleStockId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM stdin;
\.
COPY "Sales"."SalesOrderVehicleDetail" ("SalesOrderVehicleDetailId", "SalesOrderVehicleId", "LineItemNumber", "SalePrice", "LineItemDiscount", "DerivedDiscountedSalePrice", "ManufacturerVehicleStockId", "UserAuthorizationId", "SysStartTime", "SysEndTime", "RowLevelHashKey", "TransactionNumber", "Note", "PriorRowLevelHashKey", "FireAuditTrigger") FROM '$$PATH$$/3725.dat';

--
-- Name: Audit_HumanResourcesStaffHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_HumanResourcesStaffHistory_Id"', 1, false);


--
-- Name: Audit_LocaleCountryHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_LocaleCountryHistory_Id"', 4, true);


--
-- Name: Audit_ProductionManufacturerModelHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_ProductionManufacturerModelHistory_Id"', 1, false);


--
-- Name: Audit_ProductionManufacturerVehicleMakeHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_ProductionManufacturerVehicleMakeHistory_Id"', 1, false);


--
-- Name: Audit_ProductionManufacturerVehicleStockHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_ProductionManufacturerVehicleStockHistory_Id"', 1, false);


--
-- Name: Audit_SalesCustomerHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_SalesCustomerHistory_Id"', 1, false);


--
-- Name: Audit_SalesSalesCategoryThresholdHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_SalesSalesCategoryThresholdHistory_Id"', 1, false);


--
-- Name: Audit_SalesSalesOrderVehicleDetailHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_SalesSalesOrderVehicleDetailHistory_Id"', 1, false);


--
-- Name: Audit_SalesSalesOrderVehicleHistory_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Audit_SalesSalesOrderVehicleHistory_Id"', 1, false);


--
-- Name: DbSecurity_UserAuthorization_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."DbSecurity_UserAuthorization_Id"', 1, false);


--
-- Name: HumanResources_Staff_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."HumanResources_Staff_Id"', 1, false);


--
-- Name: Locale_Country_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Locale_Country_Id"', 1, false);


--
-- Name: Production_ManufacturerModel_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Production_ManufacturerModel_Id"', 1, false);


--
-- Name: Production_ManufacturerVehicleMake_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Production_ManufacturerVehicleMake_Id"', 1, false);


--
-- Name: Production_ManufacturerVehicleStock_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Production_ManufacturerVehicleStock_Id"', 1, false);


--
-- Name: Sales_Customer_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Sales_Customer_Id"', 1, false);


--
-- Name: Sales_SalesCategoryThreshold_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Sales_SalesCategoryThreshold_Id"', 1, false);


--
-- Name: Sales_SalesOrderVehicleDetail_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Sales_SalesOrderVehicleDetail_Id"', 1, false);


--
-- Name: Sales_SalesOrderVehicle_Id; Type: SEQUENCE SET; Schema: SequenceIdInsert; Owner: postgres
--

SELECT pg_catalog.setval('"SequenceIdInsert"."Sales_SalesOrderVehicle_Id"', 1, false);


--
-- Name: LocaleCountryHistory PK_CountryHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."LocaleCountryHistory"
    ADD CONSTRAINT "PK_CountryHistory" PRIMARY KEY ("LocaleCountryHistoryId");


--
-- Name: SalesSalesOrderVehicleHistory XPKSalesOrderVehicleHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."SalesSalesOrderVehicleHistory"
    ADD CONSTRAINT "XPKSalesOrderVehicleHistory" PRIMARY KEY ("SalesSalesOrderVehicleHistoryId");


--
-- Name: HumanResourcesStaffHistory XPKStaffHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."HumanResourcesStaffHistory"
    ADD CONSTRAINT "XPKStaffHistory" PRIMARY KEY ("StaffHistoryId");


--
-- Name: SalesCustomerHistory XPK_CustomerHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."SalesCustomerHistory"
    ADD CONSTRAINT "XPK_CustomerHistory" PRIMARY KEY ("SalesCustomerHistoryId");


--
-- Name: ProductionManufacturerVehicleMakeHistory XPK_MakeHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."ProductionManufacturerVehicleMakeHistory"
    ADD CONSTRAINT "XPK_MakeHistory" PRIMARY KEY ("ProductionManufacturerVehicleMakeHistoryId");


--
-- Name: ProductionManufacturerModelHistory XPK_ModelHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."ProductionManufacturerModelHistory"
    ADD CONSTRAINT "XPK_ModelHistory" PRIMARY KEY ("ProductionManufacturerModelHistoryId");


--
-- Name: SalesSalesOrderVehicleDetailHistory XPK_SalesDetailsHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."SalesSalesOrderVehicleDetailHistory"
    ADD CONSTRAINT "XPK_SalesDetailsHistory" PRIMARY KEY ("SalesSalesOrderVehicleDetailHistoryId");


--
-- Name: ProductionManufacturerVehicleStockHistory XPK_StockHistory; Type: CONSTRAINT; Schema: Audit; Owner: postgres
--

ALTER TABLE ONLY "Audit"."ProductionManufacturerVehicleStockHistory"
    ADD CONSTRAINT "XPK_StockHistory" PRIMARY KEY ("ProductionManufacturerVehicleStockHistoryId");


--
-- Name: UserAuthorization XPKUser_Authorization; Type: CONSTRAINT; Schema: DbSecurity; Owner: postgres
--

ALTER TABLE ONLY "DbSecurity"."UserAuthorization"
    ADD CONSTRAINT "XPKUser_Authorization" PRIMARY KEY ("UserAuthorizationId");


--
-- Name: Staff XPKStaff; Type: CONSTRAINT; Schema: HumanResources; Owner: postgres
--

ALTER TABLE ONLY "HumanResources"."Staff"
    ADD CONSTRAINT "XPKStaff" PRIMARY KEY ("StaffId");


--
-- Name: Country PK_Country; Type: CONSTRAINT; Schema: Locale; Owner: postgres
--

ALTER TABLE ONLY "Locale"."Country"
    ADD CONSTRAINT "PK_Country" PRIMARY KEY ("CountryId");


--
-- Name: ManufacturerVehicleMake PK_Make; Type: CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleMake"
    ADD CONSTRAINT "PK_Make" PRIMARY KEY ("ManufacturerVehicleMakeId");


--
-- Name: ManufacturerModel PK_Model_1; Type: CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerModel"
    ADD CONSTRAINT "PK_Model_1" PRIMARY KEY ("ManufacturerModelId");


--
-- Name: ManufacturerVehicleStock PK_Stock; Type: CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleStock"
    ADD CONSTRAINT "PK_Stock" PRIMARY KEY ("ManufacturerVehicleStockId");


--
-- Name: ManufacturerVehicleStock XAK1Manufacturer_Vehicle_Stock; Type: CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleStock"
    ADD CONSTRAINT "XAK1Manufacturer_Vehicle_Stock" UNIQUE ("StockCode");


--
-- Name: Customer PK_Customer; Type: CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."Customer"
    ADD CONSTRAINT "PK_Customer" PRIMARY KEY ("CustomerId");


--
-- Name: SalesOrderVehicleDetail PK_SalesDetails; Type: CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicleDetail"
    ADD CONSTRAINT "PK_SalesDetails" PRIMARY KEY ("SalesOrderVehicleDetailId");


--
-- Name: SalesOrderVehicleDetail XAK1Sales_Order_Vehicle_Detail; Type: CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicleDetail"
    ADD CONSTRAINT "XAK1Sales_Order_Vehicle_Detail" UNIQUE ("SalesOrderVehicleId", "ManufacturerVehicleStockId");


--
-- Name: SalesOrderVehicle XPKSales_Order_Vehicle; Type: CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicle"
    ADD CONSTRAINT "XPKSales_Order_Vehicle" PRIMARY KEY ("SalesOrderVehicleId");


--
-- Name: XIE1Human_Resources_Staff_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Human_Resources_Staff_History" ON "Audit"."HumanResourcesStaffHistory" USING btree ("StaffId", "TransactionNumber" DESC);


--
-- Name: XIE1Locale_Country_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Locale_Country_History" ON "Audit"."LocaleCountryHistory" USING btree ("CountryId", "TransactionNumber" DESC);


--
-- Name: XIE1Production_Manufacturer_Model_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Production_Manufacturer_Model_History" ON "Audit"."ProductionManufacturerModelHistory" USING btree ("ManufacturerModelId", "TransactionNumber" DESC);


--
-- Name: XIE1Production_Manufacturer_Vehicle_Make_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Production_Manufacturer_Vehicle_Make_History" ON "Audit"."ProductionManufacturerVehicleMakeHistory" USING btree ("ManufacturerVehicleMakeId", "TransactionNumber");


--
-- Name: XIE1Production_Manufacturer_Vehicle_Stock_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Production_Manufacturer_Vehicle_Stock_History" ON "Audit"."ProductionManufacturerVehicleStockHistory" USING btree ("ManufacturerVehicleStockId", "TransactionNumber" DESC);


--
-- Name: XIE1Sales_Customer_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Sales_Customer_History" ON "Audit"."SalesCustomerHistory" USING btree ("CustomerId", "TransactionNumber" DESC);


--
-- Name: XIE1Sales_Sales_Order_Vehicle_Detail_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Sales_Sales_Order_Vehicle_Detail_History" ON "Audit"."SalesSalesOrderVehicleDetailHistory" USING btree ("SalesOrderVehicleDetailId", "TransactionNumber" DESC);


--
-- Name: XIE1Sales_Sales_Order_Vehicle_History; Type: INDEX; Schema: Audit; Owner: postgres
--

CREATE INDEX "XIE1Sales_Sales_Order_Vehicle_History" ON "Audit"."SalesSalesOrderVehicleHistory" USING btree ("SalesOrderVehicleId", "TransactionNumber" DESC);


--
-- Name: XIE1User_Authorization; Type: INDEX; Schema: DbSecurity; Owner: postgres
--

CREATE INDEX "XIE1User_Authorization" ON "DbSecurity"."UserAuthorization" USING btree ("GroupMemberLastName", "GroupMemberFirstName");


--
-- Name: XIE1Staff; Type: INDEX; Schema: HumanResources; Owner: postgres
--

CREATE INDEX "XIE1Staff" ON "HumanResources"."Staff" USING btree ("StaffName");


--
-- Name: XIE1Customer; Type: INDEX; Schema: Sales; Owner: postgres
--

CREATE INDEX "XIE1Customer" ON "Sales"."Customer" USING btree ("CustomerName");


--
-- Name: Staff uTd_HumanResourcesStaff; Type: TRIGGER; Schema: HumanResources; Owner: postgres
--

CREATE TRIGGER "uTd_HumanResourcesStaff" AFTER DELETE ON "HumanResources"."Staff" FOR EACH ROW EXECUTE PROCEDURE "HumanResources"."funcDeleteStaffHistory"();


--
-- Name: Staff uTi_HumanResourcesStaff; Type: TRIGGER; Schema: HumanResources; Owner: postgres
--

CREATE TRIGGER "uTi_HumanResourcesStaff" AFTER INSERT ON "HumanResources"."Staff" FOR EACH ROW EXECUTE PROCEDURE "HumanResources"."funcInsertStaffHistory"();


--
-- Name: Staff uTu_HumanResourcesStaff; Type: TRIGGER; Schema: HumanResources; Owner: postgres
--

CREATE TRIGGER "uTu_HumanResourcesStaff" AFTER UPDATE ON "HumanResources"."Staff" FOR EACH ROW EXECUTE PROCEDURE "HumanResources"."funcUpdateStaffHistory"();


--
-- Name: Country uTd_LocaleCountry; Type: TRIGGER; Schema: Locale; Owner: postgres
--

CREATE TRIGGER "uTd_LocaleCountry" AFTER DELETE ON "Locale"."Country" FOR EACH ROW EXECUTE PROCEDURE "Locale"."funcDeleteCountryHistory"();


--
-- Name: Country uTi_LocaleCountry; Type: TRIGGER; Schema: Locale; Owner: postgres
--

CREATE TRIGGER "uTi_LocaleCountry" AFTER INSERT ON "Locale"."Country" FOR EACH ROW EXECUTE PROCEDURE "Locale"."funcInsertCountryHistory"();


--
-- Name: Country uTu_LocaleCountry; Type: TRIGGER; Schema: Locale; Owner: postgres
--

CREATE TRIGGER "uTu_LocaleCountry" AFTER UPDATE ON "Locale"."Country" FOR EACH ROW EXECUTE PROCEDURE "Locale"."funcUpdateCountryHistory"();


--
-- Name: ManufacturerModel uTd_ProductionManufacturerModel; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTd_ProductionManufacturerModel" AFTER DELETE ON "Production"."ManufacturerModel" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcDeleteManufacturerModelHistory"();


--
-- Name: ManufacturerVehicleMake uTd_ProductionManufacturerVehicleMake; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTd_ProductionManufacturerVehicleMake" AFTER DELETE ON "Production"."ManufacturerVehicleMake" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcDeleteManufacturerVehicleMakeHistory"();


--
-- Name: ManufacturerVehicleStock uTd_ProductionManufacturerVehicleStock; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTd_ProductionManufacturerVehicleStock" AFTER DELETE ON "Production"."ManufacturerVehicleStock" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcDeleteManufacturerVehicleStockHistory"();


--
-- Name: ManufacturerModel uTi_ProductionManufacturerModel; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTi_ProductionManufacturerModel" AFTER INSERT ON "Production"."ManufacturerModel" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcInsertManufacturerModelHistory"();


--
-- Name: ManufacturerVehicleMake uTi_ProductionManufacturerVehicleMake; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTi_ProductionManufacturerVehicleMake" AFTER INSERT ON "Production"."ManufacturerVehicleMake" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcInsertManufacturerVehicleMakeHistory"();


--
-- Name: ManufacturerVehicleStock uTi_ProductionManufacturerVehicleStock; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTi_ProductionManufacturerVehicleStock" AFTER INSERT ON "Production"."ManufacturerVehicleStock" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcInsertManufacturerVehicleStockHistory"();


--
-- Name: ManufacturerModel uTu_ProductionManufacturerModel; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTu_ProductionManufacturerModel" AFTER UPDATE ON "Production"."ManufacturerModel" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcUpdateManufacturerModelHistory"();


--
-- Name: ManufacturerVehicleMake uTu_ProductionManufacturerVehicleMake; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTu_ProductionManufacturerVehicleMake" AFTER UPDATE ON "Production"."ManufacturerVehicleMake" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcUpdateManufacturerVehicleMakeHistory"();


--
-- Name: ManufacturerVehicleStock uTu_ProductionManufacturerVehicleStock; Type: TRIGGER; Schema: Production; Owner: postgres
--

CREATE TRIGGER "uTu_ProductionManufacturerVehicleStock" AFTER UPDATE ON "Production"."ManufacturerVehicleStock" FOR EACH ROW EXECUTE PROCEDURE "Production"."funcUpdateManufacturerVehicleStockHistory"();


--
-- Name: Customer uTd_SalesCustomer; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTd_SalesCustomer" AFTER DELETE ON "Sales"."Customer" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcDeleteCustomerHistory"();


--
-- Name: SalesOrderVehicle uTd_SalesSalesOrderVehicle; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTd_SalesSalesOrderVehicle" AFTER DELETE ON "Sales"."SalesOrderVehicle" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcDeleteSalesOrderVehicleHistory"();


--
-- Name: SalesOrderVehicleDetail uTd_SalesSalesOrderVehicleDetail; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTd_SalesSalesOrderVehicleDetail" AFTER DELETE ON "Sales"."SalesOrderVehicleDetail" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcDeleteSalesOrderVehicleDetailHistory"();


--
-- Name: Customer uTi_SalesCustomer; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTi_SalesCustomer" AFTER INSERT ON "Sales"."Customer" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcInsertCustomerHistory"();


--
-- Name: SalesOrderVehicle uTi_SalesSalesOrderVehicle; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTi_SalesSalesOrderVehicle" AFTER INSERT ON "Sales"."SalesOrderVehicle" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcInsertSalesOrderVehicleHistory"();


--
-- Name: SalesOrderVehicleDetail uTi_SalesSalesOrderVehicleDetail; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTi_SalesSalesOrderVehicleDetail" AFTER INSERT ON "Sales"."SalesOrderVehicleDetail" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcInsertSalesOrderVehicleDetailHistory"();


--
-- Name: Customer uTu_SalesCustomer; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTu_SalesCustomer" AFTER UPDATE ON "Sales"."Customer" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcUpdateCustomerHistory"();


--
-- Name: SalesOrderVehicle uTu_SalesSalesOrderVehicle; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTu_SalesSalesOrderVehicle" AFTER UPDATE ON "Sales"."SalesOrderVehicle" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcUpdateSalesOrderVehicleHistory"();


--
-- Name: SalesOrderVehicle uTu_SalesSalesOrderVehicleCategoryDescription; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTu_SalesSalesOrderVehicleCategoryDescription" BEFORE INSERT OR UPDATE ON "Sales"."SalesOrderVehicle" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcUpdateSalesOrderVehicleCategoryDescription"();


--
-- Name: SalesOrderVehicleDetail uTu_SalesSalesOrderVehicleDetail; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTu_SalesSalesOrderVehicleDetail" AFTER UPDATE ON "Sales"."SalesOrderVehicleDetail" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcUpdateSalesOrderVehicleDetailHistory"();


--
-- Name: SalesOrderVehicleDetail uTu_SalesSalesOrderVehicleDetailDerivedDiscountedSalePrice; Type: TRIGGER; Schema: Sales; Owner: postgres
--

CREATE TRIGGER "uTu_SalesSalesOrderVehicleDetailDerivedDiscountedSalePrice" BEFORE INSERT OR UPDATE ON "Sales"."SalesOrderVehicleDetail" FOR EACH ROW EXECUTE PROCEDURE "Sales"."funcUpdateSalesOrderVehicleDetailDerivedDiscountedSalePrice"();


--
-- Name: Staff FK_Staff_Staff; Type: FK CONSTRAINT; Schema: HumanResources; Owner: postgres
--

ALTER TABLE ONLY "HumanResources"."Staff"
    ADD CONSTRAINT "FK_Staff_Staff" FOREIGN KEY ("ManagerId") REFERENCES "HumanResources"."Staff"("StaffId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Staff FK_Staff_UserAuthorization; Type: FK CONSTRAINT; Schema: HumanResources; Owner: postgres
--

ALTER TABLE ONLY "HumanResources"."Staff"
    ADD CONSTRAINT "FK_Staff_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Country FK_Country_UserAuthorization; Type: FK CONSTRAINT; Schema: Locale; Owner: postgres
--

ALTER TABLE ONLY "Locale"."Country"
    ADD CONSTRAINT "FK_Country_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerModel FK_ManufacturerModel_ManufacturerVehicleMake; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerModel"
    ADD CONSTRAINT "FK_ManufacturerModel_ManufacturerVehicleMake" FOREIGN KEY ("ManufacturerVehicleMakeId") REFERENCES "Production"."ManufacturerVehicleMake"("ManufacturerVehicleMakeId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerModel FK_ManufacturerModel_UserAuthorization; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerModel"
    ADD CONSTRAINT "FK_ManufacturerModel_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerVehicleMake FK_ManufacturerVehicleMake_Country; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleMake"
    ADD CONSTRAINT "FK_ManufacturerVehicleMake_Country" FOREIGN KEY ("CountryId") REFERENCES "Locale"."Country"("CountryId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerVehicleMake FK_ManufacturerVehicleMake_UserAuthorization; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleMake"
    ADD CONSTRAINT "FK_ManufacturerVehicleMake_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerVehicleStock FK_ManufacturerVehicleStock_ManufacturerModel; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleStock"
    ADD CONSTRAINT "FK_ManufacturerVehicleStock_ManufacturerModel" FOREIGN KEY ("ModelId") REFERENCES "Production"."ManufacturerModel"("ManufacturerModelId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ManufacturerVehicleStock FK_ManufacturerVehicleStock_UserAuthorization; Type: FK CONSTRAINT; Schema: Production; Owner: postgres
--

ALTER TABLE ONLY "Production"."ManufacturerVehicleStock"
    ADD CONSTRAINT "FK_ManufacturerVehicleStock_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Customer FK_Customer_Country; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."Customer"
    ADD CONSTRAINT "FK_Customer_Country" FOREIGN KEY ("CountryId") REFERENCES "Locale"."Country"("CountryId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Customer FK_Customer_UserAuthorization; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."Customer"
    ADD CONSTRAINT "FK_Customer_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicleDetail FK_SalesOrderVehicleDetail_ManufacturerVehicleStock; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicleDetail"
    ADD CONSTRAINT "FK_SalesOrderVehicleDetail_ManufacturerVehicleStock" FOREIGN KEY ("ManufacturerVehicleStockId") REFERENCES "Production"."ManufacturerVehicleStock"("ManufacturerVehicleStockId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicleDetail FK_SalesOrderVehicleDetail_SalesOrderVehicle; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicleDetail"
    ADD CONSTRAINT "FK_SalesOrderVehicleDetail_SalesOrderVehicle" FOREIGN KEY ("SalesOrderVehicleId") REFERENCES "Sales"."SalesOrderVehicle"("SalesOrderVehicleId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicleDetail FK_SalesOrderVehicleDetail_UserAuthorization; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicleDetail"
    ADD CONSTRAINT "FK_SalesOrderVehicleDetail_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicle FK_SalesOrderVehicle_Customer; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicle"
    ADD CONSTRAINT "FK_SalesOrderVehicle_Customer" FOREIGN KEY ("CustomerId") REFERENCES "Sales"."Customer"("CustomerId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicle FK_SalesOrderVehicle_Staff; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicle"
    ADD CONSTRAINT "FK_SalesOrderVehicle_Staff" FOREIGN KEY ("StaffId") REFERENCES "HumanResources"."Staff"("StaffId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SalesOrderVehicle FK_SalesOrderVehicle_UserAuthorization; Type: FK CONSTRAINT; Schema: Sales; Owner: postgres
--

ALTER TABLE ONLY "Sales"."SalesOrderVehicle"
    ADD CONSTRAINT "FK_SalesOrderVehicle_UserAuthorization" FOREIGN KEY ("UserAuthorizationId") REFERENCES "DbSecurity"."UserAuthorization"("UserAuthorizationId") ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

